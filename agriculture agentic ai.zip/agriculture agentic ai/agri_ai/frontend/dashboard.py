"""
Streamlit Dashboard for Agricultural Decision Support System
"""

import streamlit as st
import pandas as pd
import numpy as np
import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots
import requests
import json
from datetime import datetime
import time

# Page configuration
st.set_page_config(
    page_title="Agricultural Decision Support System",
    page_icon="🌾",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Custom CSS
st.markdown("""
<style>
    .main-header {
        font-size: 2.5rem;
        color: #2E8B57;
        text-align: center;
        margin-bottom: 2rem;
    }
    .metric-card {
        background-color: #f0f2f6;
        padding: 1rem;
        border-radius: 0.5rem;
        border-left: 4px solid #2E8B57;
    }
    .recommendation-card {
        background-color: #e8f5e8;
        padding: 1rem;
        border-radius: 0.5rem;
        margin: 0.5rem 0;
        border-left: 4px solid #4CAF50;
    }
    .warning-card {
        background-color: #fff3cd;
        padding: 1rem;
        border-radius: 0.5rem;
        margin: 0.5rem 0;
        border-left: 4px solid #ffc107;
    }
    .success-card {
        background-color: #d4edda;
        padding: 1rem;
        border-radius: 0.5rem;
        margin: 0.5rem 0;
        border-left: 4px solid #28a745;
    }
</style>
""", unsafe_allow_html=True)

# Backend API configuration
BACKEND_URL = "http://localhost:5000"

def check_backend_connection():
    """Check if backend is running"""
    try:
        response = requests.get(f"{BACKEND_URL}/health", timeout=5)
        return response.status_code == 200
    except:
        return False

def make_api_request(endpoint, method="GET", data=None):
    """Make API request to backend"""
    try:
        if method == "GET":
            response = requests.get(f"{BACKEND_URL}{endpoint}", timeout=10)
        elif method == "POST":
            response = requests.post(f"{BACKEND_URL}{endpoint}", json=data, timeout=10)
        
        if response.status_code == 200:
            return response.json()
        else:
            st.error(f"API Error: {response.status_code}")
            return None
    except Exception as e:
        st.error(f"Connection Error: {str(e)}")
        return None

def display_header():
    """Display the main header"""
    st.markdown('<h1 class="main-header">🌾 Agricultural Decision Support System</h1>', unsafe_allow_html=True)
    st.markdown("### AI-Powered Crop Yield Prediction & Sustainability Recommendations")
    
    # Status indicator
    if check_backend_connection():
        st.success("✅ Backend connected successfully")
    else:
        st.error("❌ Backend not connected. Please start the Flask server.")

def display_sidebar():
    """Display sidebar with input form"""
    st.sidebar.header("🌱 Input Parameters")
    
    # Crop selection
    crop_options = ['wheat', 'rice', 'maize', 'sugarcane', 'cotton', 'soybean', 'potato', 'tomato', 'onion', 'chili']
    selected_crop = st.sidebar.selectbox("Select Crop", crop_options, index=0)
    
    # Soil type
    soil_options = ['loamy', 'clay', 'sandy', 'silty', 'peaty', 'chalky']
    selected_soil = st.sidebar.selectbox("Soil Type", soil_options, index=0)
    
    # Rainfall
    rainfall = st.sidebar.slider("Annual Rainfall (mm)", 200, 2000, 600, 50)
    
    # Fertilizer type
    fertilizer_options = ['urea', 'npk', 'compost', 'organic', 'dap', 'mop', 'vermicompost', 'biofertilizer']
    selected_fertilizer = st.sidebar.selectbox("Fertilizer Type", fertilizer_options, index=0)
    
    # pH level
    ph_level = st.sidebar.slider("Soil pH Level", 4.0, 9.0, 6.5, 0.1)
    
    # Organic matter
    organic_matter = st.sidebar.slider("Organic Matter (%)", 0.5, 8.0, 2.1, 0.1)
    
    # Optional parameters
    st.sidebar.subheader("Additional Parameters")
    
    # Previous crop
    previous_crop_options = ['none', 'wheat', 'rice', 'maize', 'soybean', 'cotton', 'fallow']
    previous_crop = st.sidebar.selectbox("Previous Crop", previous_crop_options, index=6)
    
    # Season
    season_options = ['kharif', 'rabi', 'zaid', 'annual']
    season = st.sidebar.selectbox("Season", season_options, index=0)
    
    # Temperature and humidity
    temperature = st.sidebar.slider("Average Temperature (°C)", 15, 40, 25, 1)
    humidity = st.sidebar.slider("Average Humidity (%)", 30, 90, 70, 5)
    
    # Budget constraint
    budget = st.sidebar.number_input("Budget Constraint ($)", 100, 5000, 1000, 100)
    
    return {
        'crop': selected_crop,
        'soil_type': selected_soil,
        'rainfall_mm': rainfall,
        'fertilizer_type': selected_fertilizer,
        'ph_level': ph_level,
        'organic_matter': organic_matter,
        'previous_crop': previous_crop if previous_crop != 'none' else None,
        'season': season,
        'temperature_avg': temperature,
        'humidity_avg': humidity,
        'budget_constraint': budget
    }

def display_prediction_results(data):
    """Display prediction results"""
    if not data:
        return
    
    prediction = data.get('prediction', {})
    sustainability_recs = data.get('sustainability_recommendations', {})
    optimization_recs = data.get('optimization_recommendations', {})
    kg_analysis = data.get('knowledge_graph_analysis', {})
    feature_importance = data.get('feature_importance', {})
    
    # Main prediction metrics
    col1, col2, col3, col4 = st.columns(4)
    
    with col1:
        st.metric(
            "Predicted Yield",
            f"{prediction.get('predicted_yield', 0):.2f} {prediction.get('unit', 'tons/ha')}",
            delta=None
        )
    
    with col2:
        confidence = prediction.get('confidence', 0)
        st.metric(
            "Confidence",
            f"{confidence:.1%}",
            delta=None
        )
    
    with col3:
        sustainability_score = kg_analysis.get('sustainability_score', 0)
        st.metric(
            "Sustainability Score",
            f"{sustainability_score:.2f}",
            delta=None
        )
    
    with col4:
        optimization_score = optimization_recs.get('optimization_score', 0)
        st.metric(
            "Optimization Score",
            f"{optimization_score:.2f}",
            delta=None
        )

def display_sustainability_recommendations(sustainability_recs):
    """Display sustainability recommendations"""
    st.subheader("🌱 Sustainability Recommendations")
    
    if not sustainability_recs:
        st.warning("No sustainability recommendations available")
        return
    
    # Overall sustainability score
    overall_score = sustainability_recs.get('overall_sustainability_score', 0)
    st.markdown(f"**Overall Sustainability Score: {overall_score:.2f}/1.0**")
    
    # Progress bar
    st.progress(overall_score)
    
    # Key benefits
    key_benefits = sustainability_recs.get('key_benefits', [])
    if key_benefits:
        st.markdown("**Key Benefits:**")
        for benefit in key_benefits:
            st.markdown(f"• {benefit}")
    
    # Category-wise recommendations
    categories = ['soil_health', 'water_conservation', 'fertilizer_optimization', 
                 'crop_rotation', 'organic_practices', 'environmental_impact']
    
    for category in categories:
        if category in sustainability_recs and isinstance(sustainability_recs[category], dict):
            rec_data = sustainability_recs[category]
            recommendations = rec_data.get('recommendations', [])
            priority = rec_data.get('priority', 'medium')
            implementation = rec_data.get('implementation', 'medium')
            
            if recommendations:
                st.markdown(f"**{category.replace('_', ' ').title()}**")
                
                # Priority indicator
                priority_color = {'high': '🔴', 'medium': '🟡', 'low': '🟢'}.get(priority, '🟡')
                st.markdown(f"{priority_color} Priority: {priority.title()} | Implementation: {implementation.title()}")
                
                for rec in recommendations:
                    st.markdown(f"• {rec}")
                st.markdown("---")

def display_optimization_recommendations(optimization_recs):
    """Display optimization recommendations"""
    st.subheader("⚡ Optimization Recommendations")
    
    if not optimization_recs:
        st.warning("No optimization recommendations available")
        return
    
    # Optimization score
    optimization_score = optimization_recs.get('optimization_score', 0)
    st.markdown(f"**Optimization Score: {optimization_score:.2f}/1.0**")
    
    # Cost breakdown
    cost_breakdown = optimization_recs.get('cost_breakdown', {})
    if cost_breakdown:
        st.markdown("**Cost Breakdown:**")
        col1, col2 = st.columns(2)
        
        with col1:
            st.metric("Fertilizer Cost", f"${cost_breakdown.get('fertilizer_cost', 0):.2f}")
            st.metric("Irrigation Cost", f"${cost_breakdown.get('irrigation_cost', 0):.2f}")
        
        with col2:
            st.metric("Pest Control Cost", f"${cost_breakdown.get('pest_control_cost', 0):.2f}")
            st.metric("Total Cost", f"${cost_breakdown.get('total_cost', 0):.2f}")
    
    # Implementation plan
    implementation_plan = optimization_recs.get('implementation_plan', [])
    if implementation_plan:
        st.markdown("**Implementation Plan:**")
        for phase in implementation_plan:
            with st.expander(f"Phase {phase['phase']}: {phase['title']}"):
                st.markdown(f"**Duration:** {phase['duration']}")
                st.markdown(f"**Cost:** ${phase['cost']:.2f}")
                st.markdown("**Actions:**")
                for action in phase['actions']:
                    st.markdown(f"• {action}")
    
    # Expected benefits
    expected_benefits = optimization_recs.get('expected_benefits', {})
    if expected_benefits:
        st.markdown("**Expected Benefits:**")
        col1, col2, col3 = st.columns(3)
        
        with col1:
            st.metric("Yield Increase", f"{expected_benefits.get('yield_increase_percent', 0):.1f}%")
        
        with col2:
            st.metric("Water Savings", f"{expected_benefits.get('water_savings_percent', 0):.1f}%")
        
        with col3:
            st.metric("ROI", f"{expected_benefits.get('estimated_roi', 0):.1f}%")

def display_feature_importance(feature_importance):
    """Display feature importance chart"""
    st.subheader("📊 Feature Importance")
    
    if not feature_importance:
        st.warning("No feature importance data available")
        return
    
    # Create feature importance chart
    features = list(feature_importance.keys())
    importance_values = list(feature_importance.values())
    
    # Sort by importance
    sorted_data = sorted(zip(features, importance_values), key=lambda x: x[1], reverse=True)
    features, importance_values = zip(*sorted_data)
    
    # Create horizontal bar chart
    fig = px.bar(
        x=importance_values,
        y=features,
        orientation='h',
        title="Feature Importance for Yield Prediction",
        labels={'x': 'Importance Score', 'y': 'Features'},
        color=importance_values,
        color_continuous_scale='Viridis'
    )
    
    fig.update_layout(
        height=400,
        showlegend=False
    )
    
    st.plotly_chart(fig, use_container_width=True)

def display_visualizations(data):
    """Display various visualizations"""
    st.subheader("📈 Data Visualizations")
    
    # Create tabs for different visualizations
    tab1, tab2, tab3 = st.tabs(["Yield Analysis", "Sustainability Metrics", "Cost Analysis"])
    
    with tab1:
        display_yield_analysis(data)
    
    with tab2:
        display_sustainability_metrics(data)
    
    with tab3:
        display_cost_analysis(data)

def display_yield_analysis(data):
    """Display yield analysis charts"""
    prediction = data.get('prediction', {})
    kg_analysis = data.get('knowledge_graph_analysis', {})
    
    # Yield prediction vs optimal
    col1, col2 = st.columns(2)
    
    with col1:
        predicted_yield = prediction.get('predicted_yield', 0)
        optimal_yield = 4.0  # Assume optimal yield
        
        fig = go.Figure(data=[
            go.Bar(name='Predicted', x=['Yield'], y=[predicted_yield], marker_color='lightblue'),
            go.Bar(name='Optimal', x=['Yield'], y=[optimal_yield], marker_color='lightgreen')
        ])
        
        fig.update_layout(
            title="Predicted vs Optimal Yield",
            yaxis_title="Yield (tons/ha)",
            height=300
        )
        
        st.plotly_chart(fig, use_container_width=True)
    
    with col2:
        # Confidence distribution
        confidence = prediction.get('confidence', 0)
        
        fig = go.Figure(data=[
            go.Indicator(
                mode="gauge+number",
                value=confidence * 100,
                domain={'x': [0, 1], 'y': [0, 1]},
                title={'text': "Prediction Confidence (%)"},
                gauge={'axis': {'range': [None, 100]},
                       'bar': {'color': "darkblue"},
                       'steps': [{'range': [0, 50], 'color': "lightgray"},
                                {'range': [50, 80], 'color': "yellow"},
                                {'range': [80, 100], 'color': "green"}]}
            )
        ])
        
        fig.update_layout(height=300)
        st.plotly_chart(fig, use_container_width=True)

def display_sustainability_metrics(data):
    """Display sustainability metrics"""
    sustainability_recs = data.get('sustainability_recommendations', {})
    
    if not sustainability_recs:
        st.warning("No sustainability data available")
        return
    
    # Sustainability score breakdown
    categories = ['soil_health', 'water_conservation', 'fertilizer_optimization', 
                 'crop_rotation', 'organic_practices', 'environmental_impact']
    
    scores = []
    category_names = []
    
    for category in categories:
        if category in sustainability_recs and isinstance(sustainability_recs[category], dict):
            priority = sustainability_recs[category].get('priority', 'medium')
            priority_score = {'high': 0.8, 'medium': 0.5, 'low': 0.2}.get(priority, 0.5)
            scores.append(priority_score)
            category_names.append(category.replace('_', ' ').title())
    
    if scores:
        fig = px.pie(
            values=scores,
            names=category_names,
            title="Sustainability Priority Distribution",
            color_discrete_sequence=px.colors.qualitative.Set3
        )
        
        st.plotly_chart(fig, use_container_width=True)

def display_cost_analysis(data):
    """Display cost analysis"""
    optimization_recs = data.get('optimization_recommendations', {})
    
    if not optimization_recs:
        st.warning("No cost analysis data available")
        return
    
    cost_breakdown = optimization_recs.get('cost_breakdown', {})
    
    if cost_breakdown:
        categories = ['fertilizer_cost', 'irrigation_cost', 'pest_control_cost']
        values = [cost_breakdown.get(cat, 0) for cat in categories]
        labels = ['Fertilizer', 'Irrigation', 'Pest Control']
        
        fig = px.pie(
            values=values,
            names=labels,
            title="Cost Distribution",
            color_discrete_sequence=px.colors.qualitative.Pastel
        )
        
        st.plotly_chart(fig, use_container_width=True)

def display_prediction_history():
    """Display prediction history"""
    st.subheader("📋 Prediction History")
    
    # Get prediction history from API
    history_data = make_api_request("/predictions/history")
    
    if not history_data or 'predictions' not in history_data:
        st.warning("No prediction history available")
        return
    
    predictions = history_data['predictions']
    
    if not predictions:
        st.info("No predictions made yet")
        return
    
    # Create DataFrame
    df = pd.DataFrame(predictions)
    
    # Display recent predictions
    st.markdown(f"**Recent Predictions ({len(predictions)} total)**")
    
    # Show key columns
    display_columns = ['crop', 'soil_type', 'predicted_yield', 'confidence_score', 'prediction_time']
    if all(col in df.columns for col in display_columns):
        st.dataframe(
            df[display_columns].head(10),
            use_container_width=True
        )
    
    # Yield trend chart
    if 'predicted_yield' in df.columns and 'prediction_time' in df.columns:
        df['prediction_time'] = pd.to_datetime(df['prediction_time'])
        df_sorted = df.sort_values('prediction_time')
        
        fig = px.line(
            df_sorted,
            x='prediction_time',
            y='predicted_yield',
            title="Yield Prediction Trend",
            labels={'predicted_yield': 'Predicted Yield (tons/ha)', 'prediction_time': 'Date'}
        )
        
        st.plotly_chart(fig, use_container_width=True)

def main():
    """Main application function"""
    display_header()
    
    # Check backend connection
    if not check_backend_connection():
        st.error("Please start the Flask backend server first!")
        st.code("cd agri_ai/backend && python app.py")
        return
    
    # Sidebar
    input_params = display_sidebar()
    
    # Main content
    col1, col2 = st.columns([2, 1])
    
    with col1:
        st.subheader("🔮 Yield Prediction & Analysis")
        
        # Predict button
        if st.button("🚀 Get Prediction & Recommendations", type="primary"):
            with st.spinner("Analyzing your farming parameters..."):
                # Make prediction request
                prediction_data = make_api_request("/predict", method="POST", data=input_params)
                
                if prediction_data:
                    # Store in session state
                    st.session_state.prediction_data = prediction_data
                    st.success("Analysis completed successfully!")
                else:
                    st.error("Failed to get prediction. Please try again.")
    
    with col2:
        st.subheader("📊 Quick Stats")
        
        # Display quick stats if prediction data exists
        if 'prediction_data' in st.session_state:
            data = st.session_state.prediction_data
            prediction = data.get('prediction', {})
            
            st.metric("Predicted Yield", f"{prediction.get('predicted_yield', 0):.2f} tons/ha")
            st.metric("Confidence", f"{prediction.get('confidence', 0):.1%}")
            
            kg_analysis = data.get('knowledge_graph_analysis', {})
            st.metric("Sustainability", f"{kg_analysis.get('sustainability_score', 0):.2f}")
    
    # Display results if available
    if 'prediction_data' in st.session_state:
        data = st.session_state.prediction_data
        
        # Main results
        display_prediction_results(data)
        
        # Tabs for different sections
        tab1, tab2, tab3, tab4, tab5 = st.tabs([
            "🌱 Sustainability", "⚡ Optimization", "📊 Features", "📈 Visualizations", "📋 History"
        ])
        
        with tab1:
            display_sustainability_recommendations(data.get('sustainability_recommendations', {}))
        
        with tab2:
            display_optimization_recommendations(data.get('optimization_recommendations', {}))
        
        with tab3:
            display_feature_importance(data.get('feature_importance', {}))
        
        with tab4:
            display_visualizations(data)
        
        with tab5:
            display_prediction_history()
    
    # Footer
    st.markdown("---")
    st.markdown("### 🌾 About This System")
    st.markdown("""
    This Agricultural Decision Support System uses advanced AI models to:
    - **Predict crop yields** based on soil, climate, and farming practices
    - **Provide sustainability recommendations** for eco-friendly farming
    - **Optimize farming practices** for maximum yield and minimal environmental impact
    - **Explain predictions** using SHAP values for transparency
    """)

if __name__ == "__main__":
    main()
