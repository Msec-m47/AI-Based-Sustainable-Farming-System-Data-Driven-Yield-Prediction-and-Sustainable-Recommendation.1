"""
Startup script for the Agricultural Decision Support System
"""

import subprocess
import sys
import time
import os
import signal
import threading
from pathlib import Path

def check_dependencies():
    """Check if all required dependencies are installed"""
    try:
        import flask
        import streamlit
        import pandas
        import sklearn
        import mysql.connector
        import openai
        import shap
        import plotly
        print("✅ All dependencies are installed")
        return True
    except ImportError as e:
        print(f"❌ Missing dependency: {e}")
        print("Please install requirements: pip install -r requirements.txt")
        return False

def setup_database():
    """Setup MySQL database"""
    print("🔧 Setting up database...")
    
    # Check if MySQL is running
    try:
        import mysql.connector
        connection = mysql.connector.connect(
            host='localhost',
            user='root',
            password=''
        )
        cursor = connection.cursor()
        
        # Read and execute schema
        schema_path = Path(__file__).parent / 'database' / 'schema.sql'
        if schema_path.exists():
            with open(schema_path, 'r') as f:
                schema_sql = f.read()
            
            # Split by semicolon and execute each statement
            statements = [stmt.strip() for stmt in schema_sql.split(';') if stmt.strip()]
            for statement in statements:
                if statement:
                    cursor.execute(statement)
            
            connection.commit()
            print("✅ Database schema created successfully")
        else:
            print("❌ Schema file not found")
            return False
            
        cursor.close()
        connection.close()
        return True
        
    except Exception as e:
        print(f"❌ Database setup failed: {e}")
        print("Please ensure MySQL is running and accessible")
        return False

def start_backend():
    """Start the Flask backend server"""
    print("🚀 Starting Flask backend server...")
    
    backend_dir = Path(__file__).parent / 'backend'
    os.chdir(backend_dir)
    
    try:
        # Start Flask server
        process = subprocess.Popen([
            sys.executable, 'app.py'
        ], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        
        # Wait a moment for server to start
        time.sleep(3)
        
        # Check if server is running
        if process.poll() is None:
            print("✅ Backend server started successfully")
            return process
        else:
            stdout, stderr = process.communicate()
            print(f"❌ Backend server failed to start: {stderr.decode()}")
            return None
            
    except Exception as e:
        print(f"❌ Error starting backend: {e}")
        return None

def start_frontend():
    """Start the Streamlit frontend"""
    print("🌐 Starting Streamlit frontend...")
    
    frontend_dir = Path(__file__).parent / 'frontend'
    os.chdir(frontend_dir)
    
    try:
        # Start Streamlit server
        process = subprocess.Popen([
            sys.executable, '-m', 'streamlit', 'run', 'dashboard.py',
            '--server.port', '8501',
            '--server.address', '0.0.0.0'
        ], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        
        # Wait a moment for server to start
        time.sleep(5)
        
        # Check if server is running
        if process.poll() is None:
            print("✅ Frontend server started successfully")
            return process
        else:
            stdout, stderr = process.communicate()
            print(f"❌ Frontend server failed to start: {stderr.decode()}")
            return None
            
    except Exception as e:
        print(f"❌ Error starting frontend: {e}")
        return None

def main():
    """Main startup function"""
    print("🌾 Agricultural Decision Support System Startup")
    print("=" * 50)
    
    # Check dependencies
    if not check_dependencies():
        sys.exit(1)
    
    # Setup database
    if not setup_database():
        print("⚠️  Database setup failed, but continuing...")
    
    # Start backend
    backend_process = start_backend()
    if not backend_process:
        print("❌ Cannot start system without backend")
        sys.exit(1)
    
    # Start frontend
    frontend_process = start_frontend()
    if not frontend_process:
        print("❌ Cannot start system without frontend")
        backend_process.terminate()
        sys.exit(1)
    
    print("\n🎉 System started successfully!")
    print("=" * 50)
    print("📊 Backend API: http://localhost:5000")
    print("🌐 Frontend Dashboard: http://localhost:8501")
    print("=" * 50)
    print("Press Ctrl+C to stop the system")
    
    try:
        # Keep the script running
        while True:
            time.sleep(1)
            
            # Check if processes are still running
            if backend_process.poll() is not None:
                print("❌ Backend process stopped unexpectedly")
                break
                
            if frontend_process.poll() is not None:
                print("❌ Frontend process stopped unexpectedly")
                break
                
    except KeyboardInterrupt:
        print("\n🛑 Shutting down system...")
        
        # Terminate processes
        if backend_process:
            backend_process.terminate()
            print("✅ Backend stopped")
            
        if frontend_process:
            frontend_process.terminate()
            print("✅ Frontend stopped")
            
        print("👋 System shutdown complete")

if __name__ == "__main__":
    main()
