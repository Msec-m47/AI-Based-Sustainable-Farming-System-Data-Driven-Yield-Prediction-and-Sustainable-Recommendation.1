-- Agricultural Decision Support System Database Schema

CREATE DATABASE IF NOT EXISTS agri_ai_db;
USE agri_ai_db;

-- Users table
CREATE TABLE users (
    id INT PRIMARY KEY AUTO_INCREMENT,
    username VARCHAR(50) UNIQUE NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Input parameters table
CREATE TABLE inputs (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT,
    crop VARCHAR(50) NOT NULL,
    soil_type VARCHAR(50) NOT NULL,
    rainfall_mm DECIMAL(8,2) NOT NULL,
    fertilizer_type VARCHAR(50) NOT NULL,
    ph_level DECIMAL(3,1) NOT NULL,
    organic_matter DECIMAL(3,1) NOT NULL,
    previous_crop VARCHAR(50),
    season VARCHAR(20) NOT NULL,
    temperature_avg DECIMAL(4,1),
    humidity_avg DECIMAL(4,1),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Predictions table
CREATE TABLE predictions (
    id INT PRIMARY KEY AUTO_INCREMENT,
    input_id INT NOT NULL,
    predicted_yield DECIMAL(8,2) NOT NULL,
    confidence_score DECIMAL(4,3),
    model_version VARCHAR(20) DEFAULT 'v1.0',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (input_id) REFERENCES inputs(id) ON DELETE CASCADE
);

-- Recommendations table
CREATE TABLE recommendations (
    id INT PRIMARY KEY AUTO_INCREMENT,
    input_id INT NOT NULL,
    recommendation_type ENUM('sustainability', 'optimization', 'rotation', 'fertilizer') NOT NULL,
    recommendation_text TEXT NOT NULL,
    priority ENUM('high', 'medium', 'low') DEFAULT 'medium',
    implementation_difficulty ENUM('easy', 'medium', 'hard') DEFAULT 'medium',
    expected_impact DECIMAL(4,2),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (input_id) REFERENCES inputs(id) ON DELETE CASCADE
);

-- Knowledge graph relationships
CREATE TABLE crop_soil_compatibility (
    id INT PRIMARY KEY AUTO_INCREMENT,
    crop VARCHAR(50) NOT NULL,
    soil_type VARCHAR(50) NOT NULL,
    compatibility_score DECIMAL(3,2) NOT NULL,
    optimal_ph_min DECIMAL(3,1),
    optimal_ph_max DECIMAL(3,1),
    optimal_rainfall_min DECIMAL(8,2),
    optimal_rainfall_max DECIMAL(8,2),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Fertilizer recommendations
CREATE TABLE fertilizer_recommendations (
    id INT PRIMARY KEY AUTO_INCREMENT,
    crop VARCHAR(50) NOT NULL,
    soil_type VARCHAR(50) NOT NULL,
    fertilizer_type VARCHAR(50) NOT NULL,
    application_rate DECIMAL(6,2),
    application_timing VARCHAR(100),
    sustainability_rating ENUM('high', 'medium', 'low') DEFAULT 'medium',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Insert sample data for knowledge graph
INSERT INTO crop_soil_compatibility (crop, soil_type, compatibility_score, optimal_ph_min, optimal_ph_max, optimal_rainfall_min, optimal_rainfall_max) VALUES
('wheat', 'loamy', 0.95, 6.0, 7.5, 500, 800),
('wheat', 'clay', 0.80, 6.0, 7.5, 500, 800),
('wheat', 'sandy', 0.70, 6.0, 7.5, 500, 800),
('rice', 'clay', 0.90, 6.5, 7.5, 700, 1200),
('rice', 'loamy', 0.85, 6.5, 7.5, 700, 1200),
('rice', 'sandy', 0.60, 6.5, 7.5, 700, 1200),
('maize', 'loamy', 0.90, 6.0, 7.0, 400, 800),
('maize', 'sandy', 0.85, 6.0, 7.0, 400, 800),
('maize', 'clay', 0.75, 6.0, 7.0, 400, 800),
('sugarcane', 'clay', 0.95, 6.5, 7.5, 1000, 2000),
('sugarcane', 'loamy', 0.90, 6.5, 7.5, 1000, 2000),
('cotton', 'loamy', 0.85, 6.0, 8.0, 300, 600),
('cotton', 'sandy', 0.80, 6.0, 8.0, 300, 600),
('soybean', 'loamy', 0.90, 6.0, 7.0, 300, 700),
('soybean', 'sandy', 0.85, 6.0, 7.0, 300, 700);

-- Insert fertilizer recommendations
INSERT INTO fertilizer_recommendations (crop, soil_type, fertilizer_type, application_rate, application_timing, sustainability_rating) VALUES
('wheat', 'loamy', 'compost', 5.0, 'Before sowing', 'high'),
('wheat', 'loamy', 'urea', 2.0, 'Split application', 'medium'),
('rice', 'clay', 'organic', 8.0, 'Puddling stage', 'high'),
('rice', 'clay', 'compost', 6.0, 'Before transplanting', 'high'),
('maize', 'sandy', 'npk', 3.0, 'At sowing and top dressing', 'medium'),
('maize', 'sandy', 'compost', 4.0, 'Before sowing', 'high'),
('sugarcane', 'clay', 'organic', 10.0, 'Ratoon management', 'high'),
('cotton', 'loamy', 'urea', 2.5, 'Split application', 'medium'),
('soybean', 'sandy', 'compost', 3.0, 'Before sowing', 'high');
