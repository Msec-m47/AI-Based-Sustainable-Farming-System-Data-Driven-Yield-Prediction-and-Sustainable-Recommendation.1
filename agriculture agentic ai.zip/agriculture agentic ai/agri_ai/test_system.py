"""
Test script for the Agricultural Decision Support System
"""

import requests
import json
import time
import sys
from pathlib import Path

# Test configuration
BACKEND_URL = "http://localhost:5000"
FRONTEND_URL = "http://localhost:8501"

def test_backend_health():
    """Test backend health endpoint"""
    print("🔍 Testing backend health...")
    try:
        response = requests.get(f"{BACKEND_URL}/health", timeout=5)
        if response.status_code == 200:
            data = response.json()
            print(f"✅ Backend is healthy: {data.get('status', 'unknown')}")
            return True
        else:
            print(f"❌ Backend health check failed: {response.status_code}")
            return False
    except Exception as e:
        print(f"❌ Backend connection failed: {e}")
        return False

def test_prediction_endpoint():
    """Test prediction endpoint"""
    print("🔍 Testing prediction endpoint...")
    
    test_data = {
        "crop": "wheat",
        "soil_type": "loamy",
        "rainfall_mm": 600,
        "fertilizer_type": "urea",
        "ph_level": 6.5,
        "organic_matter": 2.1,
        "previous_crop": "soybean",
        "season": "rabi",
        "temperature_avg": 22,
        "humidity_avg": 65,
        "budget_constraint": 1000
    }
    
    try:
        response = requests.post(f"{BACKEND_URL}/predict", json=test_data, timeout=10)
        if response.status_code == 200:
            data = response.json()
            prediction = data.get('prediction', {})
            print(f"✅ Prediction successful:")
            print(f"   - Predicted yield: {prediction.get('predicted_yield', 'N/A')} tons/ha")
            print(f"   - Confidence: {prediction.get('confidence', 'N/A')}")
            return True
        else:
            print(f"❌ Prediction failed: {response.status_code}")
            print(f"   Response: {response.text}")
            return False
    except Exception as e:
        print(f"❌ Prediction request failed: {e}")
        return False

def test_crop_recommendations():
    """Test crop recommendations endpoint"""
    print("🔍 Testing crop recommendations...")
    
    test_data = {
        "soil_type": "loamy",
        "ph_level": 6.5,
        "rainfall": 600,
        "season": "rabi"
    }
    
    try:
        response = requests.post(f"{BACKEND_URL}/crop_recommendations", json=test_data, timeout=10)
        if response.status_code == 200:
            data = response.json()
            recommendations = data.get('recommendations', [])
            print(f"✅ Crop recommendations received: {len(recommendations)} crops")
            if recommendations:
                top_crop = recommendations[0]
                print(f"   - Top recommendation: {top_crop.get('crop', 'N/A')} (score: {top_crop.get('suitability_score', 'N/A')})")
            return True
        else:
            print(f"❌ Crop recommendations failed: {response.status_code}")
            return False
    except Exception as e:
        print(f"❌ Crop recommendations request failed: {e}")
        return False

def test_fertilizer_recommendations():
    """Test fertilizer recommendations endpoint"""
    print("🔍 Testing fertilizer recommendations...")
    
    test_data = {
        "crop": "wheat",
        "soil_type": "loamy",
        "current_fertilizer": "urea"
    }
    
    try:
        response = requests.post(f"{BACKEND_URL}/fertilizer_recommendations", json=test_data, timeout=10)
        if response.status_code == 200:
            data = response.json()
            recommendations = data.get('recommendations', [])
            print(f"✅ Fertilizer recommendations received: {len(recommendations)} options")
            if recommendations:
                top_fert = recommendations[0]
                print(f"   - Top recommendation: {top_fert.get('fertilizer', 'N/A')} (sustainability: {top_fert.get('sustainability_score', 'N/A')})")
            return True
        else:
            print(f"❌ Fertilizer recommendations failed: {response.status_code}")
            return False
    except Exception as e:
        print(f"❌ Fertilizer recommendations request failed: {e}")
        return False

def test_model_info():
    """Test model info endpoint"""
    print("🔍 Testing model info...")
    
    try:
        response = requests.get(f"{BACKEND_URL}/model_info", timeout=10)
        if response.status_code == 200:
            data = response.json()
            print(f"✅ Model info received:")
            print(f"   - Model type: {data.get('model_type', 'N/A')}")
            print(f"   - Is trained: {data.get('is_trained', 'N/A')}")
            print(f"   - Feature count: {data.get('feature_count', 'N/A')}")
            return True
        else:
            print(f"❌ Model info failed: {response.status_code}")
            return False
    except Exception as e:
        print(f"❌ Model info request failed: {e}")
        return False

def test_frontend_access():
    """Test if frontend is accessible"""
    print("🔍 Testing frontend access...")
    try:
        response = requests.get(FRONTEND_URL, timeout=5)
        if response.status_code == 200:
            print("✅ Frontend is accessible")
            return True
        else:
            print(f"❌ Frontend access failed: {response.status_code}")
            return False
    except Exception as e:
        print(f"❌ Frontend connection failed: {e}")
        return False

def run_all_tests():
    """Run all tests"""
    print("🧪 Agricultural Decision Support System - Test Suite")
    print("=" * 60)
    
    tests = [
        ("Backend Health", test_backend_health),
        ("Prediction Endpoint", test_prediction_endpoint),
        ("Crop Recommendations", test_crop_recommendations),
        ("Fertilizer Recommendations", test_fertilizer_recommendations),
        ("Model Info", test_model_info),
        ("Frontend Access", test_frontend_access)
    ]
    
    results = []
    
    for test_name, test_func in tests:
        print(f"\n📋 Running {test_name}...")
        try:
            result = test_func()
            results.append((test_name, result))
        except Exception as e:
            print(f"❌ {test_name} failed with exception: {e}")
            results.append((test_name, False))
        
        time.sleep(1)  # Small delay between tests
    
    # Summary
    print("\n" + "=" * 60)
    print("📊 Test Results Summary:")
    print("=" * 60)
    
    passed = 0
    total = len(results)
    
    for test_name, result in results:
        status = "✅ PASS" if result else "❌ FAIL"
        print(f"{status} - {test_name}")
        if result:
            passed += 1
    
    print("=" * 60)
    print(f"📈 Overall: {passed}/{total} tests passed ({passed/total*100:.1f}%)")
    
    if passed == total:
        print("🎉 All tests passed! System is working correctly.")
        return True
    else:
        print("⚠️  Some tests failed. Please check the system configuration.")
        return False

def main():
    """Main test function"""
    print("Starting system tests...")
    print("Make sure the backend and frontend are running before running tests.")
    print("Backend: python agri_ai/backend/app.py")
    print("Frontend: streamlit run agri_ai/frontend/dashboard.py")
    print()
    
    # Wait for user confirmation
    input("Press Enter to start tests...")
    
    success = run_all_tests()
    
    if success:
        print("\n🚀 System is ready for use!")
        print("Frontend: http://localhost:8501")
        print("Backend API: http://localhost:5000")
    else:
        print("\n🔧 Please fix the issues and run tests again.")
        sys.exit(1)

if __name__ == "__main__":
    main()
