"""
Flask Backend for Agricultural Decision Support System
"""

from flask import Flask, request, jsonify
from flask_cors import CORS
import pandas as pd
import numpy as np
import os
import sys
from datetime import datetime
import mysql.connector
from mysql.connector import Error
import json

# Add the models directory to the path
sys.path.append(os.path.join(os.path.dirname(__file__), 'models'))

from yield_model import YieldPredictionModel
from sustainability_agent import SustainabilityAgent
from optimization_agent import OptimizationAgent
from rules import AgriculturalKnowledgeGraph

app = Flask(__name__)
CORS(app)

# Configuration
app.config['SECRET_KEY'] = 'your-secret-key-here'
app.config['MYSQL_HOST'] = os.getenv('MYSQL_HOST', 'localhost')
app.config['MYSQL_USER'] = os.getenv('MYSQL_USER', 'root')
app.config['MYSQL_PASSWORD'] = os.getenv('MYSQL_PASSWORD', '')
app.config['MYSQL_DATABASE'] = os.getenv('MYSQL_DATABASE', 'agri_ai_db')

# Initialize AI models
yield_model = YieldPredictionModel()
sustainability_agent = SustainabilityAgent()
optimization_agent = OptimizationAgent()
knowledge_graph = AgriculturalKnowledgeGraph()

# Global variable to store trained model
trained_model = None

def get_db_connection():
    """Get database connection"""
    try:
        connection = mysql.connector.connect(
            host=app.config['MYSQL_HOST'],
            user=app.config['MYSQL_USER'],
            password=app.config['MYSQL_PASSWORD'],
            database=app.config['MYSQL_DATABASE']
        )
        return connection
    except Error as e:
        print(f"Error connecting to MySQL: {e}")
        return None

def init_database():
    """Initialize database with sample data"""
    try:
        # Load sample data
        sample_data_path = os.path.join(os.path.dirname(__file__), '..', 'datasets', 'sample_agri_data.csv')
        df = pd.read_csv(sample_data_path)
        
        # Train the yield model
        global trained_model
        trained_model = YieldPredictionModel()
        r2, rmse = trained_model.train(df)
        
        print(f"Yield model trained successfully! R²: {r2:.4f}, RMSE: {rmse:.4f}")
        
        return True
    except Exception as e:
        print(f"Error initializing database: {e}")
        return False

@app.route('/health', methods=['GET'])
def health_check():
    """Health check endpoint"""
    return jsonify({
        'status': 'healthy',
        'timestamp': datetime.now().isoformat(),
        'models_loaded': trained_model is not None
    })

@app.route('/predict', methods=['POST'])
def predict_yield():
    """Predict crop yield and get recommendations"""
    try:
        data = request.get_json()
        
        # Validate required fields
        required_fields = ['crop', 'soil_type', 'rainfall_mm', 'fertilizer_type', 
                          'ph_level', 'organic_matter']
        for field in required_fields:
            if field not in data:
                return jsonify({'error': f'Missing required field: {field}'}), 400
        
        # Prepare input data
        input_data = pd.DataFrame([{
            'crop': data['crop'],
            'soil_type': data['soil_type'],
            'rainfall_mm': float(data['rainfall_mm']),
            'fertilizer_type': data['fertilizer_type'],
            'ph_level': float(data['ph_level']),
            'organic_matter': float(data['organic_matter']),
            'previous_crop': data.get('previous_crop', 'unknown'),
            'season': data.get('season', 'kharif'),
            'temperature_avg': data.get('temperature_avg', 25.0),
            'humidity_avg': data.get('humidity_avg', 70.0)
        }])
        
        # Make yield prediction
        if trained_model is None:
            return jsonify({'error': 'Model not trained yet'}), 500
        
        predicted_yield, confidence = trained_model.predict(input_data)
        
        # Get sustainability recommendations
        sustainability_recs = sustainability_agent.generate_sustainability_recommendations(
            crop=data['crop'],
            soil_type=data['soil_type'],
            rainfall=float(data['rainfall_mm']),
            fertilizer_type=data['fertilizer_type'],
            ph_level=float(data['ph_level']),
            organic_matter=float(data['organic_matter']),
            previous_crop=data.get('previous_crop'),
            season=data.get('season')
        )
        
        # Get optimization recommendations
        optimization_recs = optimization_agent.optimize_farming_practices(
            crop=data['crop'],
            soil_type=data['soil_type'],
            rainfall=float(data['rainfall_mm']),
            current_fertilizer=data['fertilizer_type'],
            ph_level=float(data['ph_level']),
            organic_matter=float(data['organic_matter']),
            budget_constraint=data.get('budget_constraint', 1000.0)
        )
        
        # Get knowledge graph analysis
        kg_analysis = knowledge_graph.analyze_farming_system(
            crop=data['crop'],
            soil_type=data['soil_type'],
            fertilizer=data['fertilizer_type'],
            ph_level=float(data['ph_level']),
            organic_matter=float(data['organic_matter']),
            rainfall=float(data['rainfall_mm'])
        )
        
        # Get feature importance
        feature_importance = trained_model.get_feature_importance()
        
        # Store prediction in database
        try:
            connection = get_db_connection()
            if connection:
                cursor = connection.cursor()
                
                # Insert input data
                cursor.execute("""
                    INSERT INTO inputs (crop, soil_type, rainfall_mm, fertilizer_type, 
                                      ph_level, organic_matter, previous_crop, season, 
                                      temperature_avg, humidity_avg)
                    VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                """, (
                    data['crop'], data['soil_type'], float(data['rainfall_mm']),
                    data['fertilizer_type'], float(data['ph_level']), 
                    float(data['organic_matter']), data.get('previous_crop'),
                    data.get('season'), data.get('temperature_avg', 25.0),
                    data.get('humidity_avg', 70.0)
                ))
                
                input_id = cursor.lastrowid
                
                # Insert prediction
                cursor.execute("""
                    INSERT INTO predictions (input_id, predicted_yield, confidence_score)
                    VALUES (%s, %s, %s)
                """, (input_id, predicted_yield, confidence))
                
                # Insert recommendations
                for category, rec_data in sustainability_recs.items():
                    if isinstance(rec_data, dict) and 'recommendations' in rec_data:
                        for rec in rec_data['recommendations']:
                            cursor.execute("""
                                INSERT INTO recommendations (input_id, recommendation_type, 
                                                          recommendation_text, priority, 
                                                          implementation_difficulty)
                                VALUES (%s, %s, %s, %s, %s)
                            """, (input_id, category, rec, 
                                rec_data.get('priority', 'medium'),
                                rec_data.get('implementation', 'medium')))
                
                connection.commit()
                cursor.close()
                connection.close()
                
        except Exception as e:
            print(f"Database error: {e}")
            # Continue without database storage
        
        # Prepare response
        response = {
            'prediction': {
                'predicted_yield': round(predicted_yield, 2),
                'confidence': round(confidence, 2),
                'unit': 'tons/ha'
            },
            'sustainability_recommendations': sustainability_recs,
            'optimization_recommendations': optimization_recs,
            'knowledge_graph_analysis': kg_analysis,
            'feature_importance': feature_importance,
            'timestamp': datetime.now().isoformat()
        }
        
        return jsonify(response)
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/crop_recommendations', methods=['POST'])
def get_crop_recommendations():
    """Get crop recommendations based on soil and climate conditions"""
    try:
        data = request.get_json()
        
        soil_type = data.get('soil_type', 'loamy')
        ph_level = float(data.get('ph_level', 6.5))
        rainfall = float(data.get('rainfall', 600))
        season = data.get('season', 'kharif')
        
        recommendations = knowledge_graph.get_crop_recommendations(
            soil_type, ph_level, rainfall, season
        )
        
        return jsonify({
            'recommendations': recommendations,
            'parameters': {
                'soil_type': soil_type,
                'ph_level': ph_level,
                'rainfall': rainfall,
                'season': season
            }
        })
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/fertilizer_recommendations', methods=['POST'])
def get_fertilizer_recommendations():
    """Get fertilizer recommendations"""
    try:
        data = request.get_json()
        
        crop = data.get('crop', 'wheat')
        soil_type = data.get('soil_type', 'loamy')
        current_fertilizer = data.get('current_fertilizer', 'urea')
        
        recommendations = knowledge_graph.get_fertilizer_recommendations(
            crop, soil_type, current_fertilizer
        )
        
        return jsonify({
            'recommendations': recommendations,
            'parameters': {
                'crop': crop,
                'soil_type': soil_type,
                'current_fertilizer': current_fertilizer
            }
        })
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/sustainability_practices', methods=['GET'])
def get_sustainability_practices():
    """Get sustainability practices by category"""
    try:
        category = request.args.get('category')
        practices = knowledge_graph.get_sustainability_practices(category)
        
        return jsonify({
            'practices': practices,
            'category': category or 'all'
        })
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/crop_rotation', methods=['POST'])
def get_crop_rotation():
    """Get crop rotation recommendations"""
    try:
        data = request.get_json()
        
        current_crop = data.get('current_crop', 'wheat')
        soil_type = data.get('soil_type', 'loamy')
        
        recommendations = knowledge_graph.get_crop_rotation_recommendations(
            current_crop, soil_type
        )
        
        return jsonify({
            'recommendations': recommendations,
            'parameters': {
                'current_crop': current_crop,
                'soil_type': soil_type
            }
        })
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/model_info', methods=['GET'])
def get_model_info():
    """Get information about the trained model"""
    try:
        if trained_model is None:
            return jsonify({'error': 'Model not trained yet'}), 500
        
        feature_importance = trained_model.get_feature_importance()
        
        return jsonify({
            'model_type': 'RandomForestRegressor',
            'feature_importance': feature_importance,
            'is_trained': trained_model.is_trained,
            'feature_count': len(trained_model.feature_columns)
        })
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/predictions/history', methods=['GET'])
def get_prediction_history():
    """Get prediction history from database"""
    try:
        connection = get_db_connection()
        if not connection:
            return jsonify({'error': 'Database connection failed'}), 500
        
        cursor = connection.cursor(dictionary=True)
        
        # Get recent predictions
        cursor.execute("""
            SELECT i.*, p.predicted_yield, p.confidence_score, p.created_at as prediction_time
            FROM inputs i
            JOIN predictions p ON i.id = p.input_id
            ORDER BY p.created_at DESC
            LIMIT 50
        """)
        
        predictions = cursor.fetchall()
        
        cursor.close()
        connection.close()
        
        return jsonify({
            'predictions': predictions,
            'count': len(predictions)
        })
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.errorhandler(404)
def not_found(error):
    return jsonify({'error': 'Endpoint not found'}), 404

@app.errorhandler(500)
def internal_error(error):
    return jsonify({'error': 'Internal server error'}), 500

if __name__ == '__main__':
    print("Initializing Agricultural Decision Support System...")
    
    # Initialize database and train model
    if init_database():
        print("System initialized successfully!")
        print("Starting Flask server...")
        app.run(debug=True, host='0.0.0.0', port=5000)
    else:
        print("Failed to initialize system. Please check your configuration.")
