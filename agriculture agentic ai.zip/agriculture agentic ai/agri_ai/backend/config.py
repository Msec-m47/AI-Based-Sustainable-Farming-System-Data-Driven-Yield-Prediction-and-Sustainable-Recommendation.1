"""
Configuration file for the Agricultural Decision Support System
"""

import os
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

class Config:
    """Base configuration class"""
    
    # Flask configuration
    SECRET_KEY = os.getenv('SECRET_KEY', 'your-secret-key-change-in-production')
    DEBUG = os.getenv('DEBUG', 'False').lower() == 'true'
    
    # Database configuration
    MYSQL_HOST = os.getenv('MYSQL_HOST', 'localhost')
    MYSQL_PORT = int(os.getenv('MYSQL_PORT', '3306'))
    MYSQL_USER = os.getenv('MYSQL_USER', 'root')
    MYSQL_PASSWORD = os.getenv('MYSQL_PASSWORD', '')
    MYSQL_DATABASE = os.getenv('MYSQL_DATABASE', 'agri_ai_db')
    
    # AI Model configuration
    OPENAI_API_KEY = os.getenv('OPENAI_API_KEY', '')
    MODEL_VERSION = os.getenv('MODEL_VERSION', 'v1.0')
    
    # File paths
    DATA_DIR = os.path.join(os.path.dirname(__file__), '..', 'datasets')
    MODELS_DIR = os.path.join(os.path.dirname(__file__), 'models')
    
    # Model parameters
    RANDOM_FOREST_PARAMS = {
        'n_estimators': 100,
        'max_depth': 10,
        'random_state': 42,
        'n_jobs': -1
    }
    
    # API configuration
    API_TIMEOUT = 30
    MAX_CONTENT_LENGTH = 16 * 1024 * 1024  # 16MB
    
    # CORS configuration
    CORS_ORIGINS = os.getenv('CORS_ORIGINS', '*').split(',')
    
    @staticmethod
    def get_database_url():
        """Get database connection URL"""
        return f"mysql://{Config.MYSQL_USER}:{Config.MYSQL_PASSWORD}@{Config.MYSQL_HOST}:{Config.MYSQL_PORT}/{Config.MYSQL_DATABASE}"

class DevelopmentConfig(Config):
    """Development configuration"""
    DEBUG = True
    MYSQL_DATABASE = 'agri_ai_dev'

class ProductionConfig(Config):
    """Production configuration"""
    DEBUG = False
    MYSQL_DATABASE = 'agri_ai_prod'

class TestingConfig(Config):
    """Testing configuration"""
    TESTING = True
    MYSQL_DATABASE = 'agri_ai_test'

# Configuration dictionary
config = {
    'development': DevelopmentConfig,
    'production': ProductionConfig,
    'testing': TestingConfig,
    'default': DevelopmentConfig
}
