"""
SHAP-based Explainability Module for Agricultural AI Models
"""

import shap
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import plotly.graph_objects as go
import plotly.express as px
from typing import Dict, List, Any, Tuple
import json

class ModelExplainer:
    def __init__(self, model, feature_columns: List[str]):
        """
        Initialize the model explainer
        
        Args:
            model: Trained ML model
            feature_columns: List of feature column names
        """
        self.model = model
        self.feature_columns = feature_columns
        self.explainer = None
        self.shap_values = None
        
    def create_explainer(self, X_train: np.ndarray, X_test: np.ndarray = None):
        """
        Create SHAP explainer for the model
        
        Args:
            X_train: Training data
            X_test: Test data (optional)
        """
        try:
            # Create TreeExplainer for Random Forest
            self.explainer = shap.TreeExplainer(self.model)
            
            # Calculate SHAP values
            if X_test is not None:
                self.shap_values = self.explainer.shap_values(X_test)
            else:
                # Use a sample of training data
                sample_size = min(100, len(X_train))
                sample_indices = np.random.choice(len(X_train), sample_size, replace=False)
                X_sample = X_train[sample_indices]
                self.shap_values = self.explainer.shap_values(X_sample)
                
        except Exception as e:
            print(f"Error creating SHAP explainer: {e}")
            self.explainer = None
            self.shap_values = None
    
    def explain_prediction(self, input_data: np.ndarray) -> Dict[str, Any]:
        """
        Explain a single prediction
        
        Args:
            input_data: Single input sample
            
        Returns:
            Dictionary containing explanation data
        """
        if self.explainer is None:
            return {"error": "Explainer not initialized"}
        
        try:
            # Get SHAP values for the input
            shap_values = self.explainer.shap_values(input_data.reshape(1, -1))
            
            # Get base value (expected output)
            base_value = self.explainer.expected_value
            
            # Calculate feature contributions
            feature_contributions = []
            for i, feature in enumerate(self.feature_columns):
                contribution = shap_values[0][i] if len(shap_values.shape) > 1 else shap_values[i]
                feature_contributions.append({
                    'feature': feature,
                    'contribution': float(contribution),
                    'abs_contribution': float(abs(contribution))
                })
            
            # Sort by absolute contribution
            feature_contributions.sort(key=lambda x: x['abs_contribution'], reverse=True)
            
            # Calculate prediction
            prediction = base_value + sum([fc['contribution'] for fc in feature_contributions])
            
            return {
                'base_value': float(base_value),
                'prediction': float(prediction),
                'feature_contributions': feature_contributions,
                'top_features': feature_contributions[:5]  # Top 5 most important features
            }
            
        except Exception as e:
            return {"error": f"Error explaining prediction: {e}"}
    
    def get_feature_importance_plot(self, max_features: int = 10) -> Dict[str, Any]:
        """
        Generate feature importance plot data
        
        Args:
            max_features: Maximum number of features to show
            
        Returns:
            Dictionary containing plot data
        """
        if self.shap_values is None:
            return {"error": "SHAP values not calculated"}
        
        try:
            # Calculate mean absolute SHAP values
            mean_shap_values = np.mean(np.abs(self.shap_values), axis=0)
            
            # Get top features
            feature_importance = []
            for i, feature in enumerate(self.feature_columns):
                feature_importance.append({
                    'feature': feature,
                    'importance': float(mean_shap_values[i])
                })
            
            # Sort by importance
            feature_importance.sort(key=lambda x: x['importance'], reverse=True)
            
            # Take top features
            top_features = feature_importance[:max_features]
            
            # Create plot data
            plot_data = {
                'features': [f['feature'] for f in top_features],
                'importance': [f['importance'] for f in top_features],
                'type': 'bar'
            }
            
            return {
                'plot_data': plot_data,
                'feature_importance': top_features
            }
            
        except Exception as e:
            return {"error": f"Error generating feature importance: {e}"}
    
    def get_waterfall_plot_data(self, input_data: np.ndarray) -> Dict[str, Any]:
        """
        Generate waterfall plot data for a single prediction
        
        Args:
            input_data: Single input sample
            
        Returns:
            Dictionary containing waterfall plot data
        """
        if self.explainer is None:
            return {"error": "Explainer not initialized"}
        
        try:
            # Get SHAP values
            shap_values = self.explainer.shap_values(input_data.reshape(1, -1))
            base_value = self.explainer.expected_value
            
            # Prepare waterfall data
            waterfall_data = []
            cumulative_value = base_value
            
            # Get feature contributions
            feature_contributions = []
            for i, feature in enumerate(self.feature_columns):
                contribution = shap_values[0][i] if len(shap_values.shape) > 1 else shap_values[i]
                feature_contributions.append({
                    'feature': feature,
                    'contribution': float(contribution)
                })
            
            # Sort by absolute contribution
            feature_contributions.sort(key=lambda x: abs(x['contribution']), reverse=True)
            
            # Build waterfall
            waterfall_data.append({
                'feature': 'Base Value',
                'value': float(base_value),
                'cumulative': float(base_value)
            })
            
            for fc in feature_contributions:
                cumulative_value += fc['contribution']
                waterfall_data.append({
                    'feature': fc['feature'],
                    'value': fc['contribution'],
                    'cumulative': float(cumulative_value)
                })
            
            return {
                'waterfall_data': waterfall_data,
                'final_prediction': float(cumulative_value)
            }
            
        except Exception as e:
            return {"error": f"Error generating waterfall plot: {e}"}
    
    def get_summary_plot_data(self, max_display: int = 10) -> Dict[str, Any]:
        """
        Generate summary plot data
        
        Args:
            max_display: Maximum number of features to display
            
        Returns:
            Dictionary containing summary plot data
        """
        if self.shap_values is None:
            return {"error": "SHAP values not calculated"}
        
        try:
            # Calculate mean absolute SHAP values
            mean_shap_values = np.mean(np.abs(self.shap_values), axis=0)
            
            # Get feature names and values
            feature_names = self.feature_columns
            feature_values = mean_shap_values
            
            # Sort by importance
            sorted_indices = np.argsort(feature_values)[::-1]
            sorted_names = [feature_names[i] for i in sorted_indices[:max_display]]
            sorted_values = [feature_values[i] for i in sorted_indices[:max_display]]
            
            return {
                'feature_names': sorted_names,
                'importance_values': sorted_values,
                'type': 'summary'
            }
            
        except Exception as e:
            return {"error": f"Error generating summary plot: {e}"}
    
    def get_partial_dependence_data(self, feature_name: str, 
                                  X_data: np.ndarray, 
                                  feature_index: int) -> Dict[str, Any]:
        """
        Generate partial dependence plot data
        
        Args:
            feature_name: Name of the feature
            X_data: Input data
            feature_index: Index of the feature in the data
            
        Returns:
            Dictionary containing partial dependence data
        """
        try:
            # Create a range of values for the feature
            feature_values = X_data[:, feature_index]
            min_val = np.min(feature_values)
            max_val = np.max(feature_values)
            
            # Create test values
            test_values = np.linspace(min_val, max_val, 50)
            
            # Calculate partial dependence
            partial_dependence = []
            for val in test_values:
                # Create test data with this feature value
                test_data = X_data.copy()
                test_data[:, feature_index] = val
                
                # Get predictions
                predictions = self.model.predict(test_data)
                partial_dependence.append(np.mean(predictions))
            
            return {
                'feature_name': feature_name,
                'feature_values': test_values.tolist(),
                'partial_dependence': partial_dependence,
                'type': 'partial_dependence'
            }
            
        except Exception as e:
            return {"error": f"Error generating partial dependence: {e}"}
    
    def get_interaction_effects(self, feature1: str, feature2: str, 
                              X_data: np.ndarray) -> Dict[str, Any]:
        """
        Calculate interaction effects between two features
        
        Args:
            feature1: First feature name
            feature2: Second feature name
            X_data: Input data
            
        Returns:
            Dictionary containing interaction data
        """
        try:
            # Find feature indices
            idx1 = self.feature_columns.index(feature1)
            idx2 = self.feature_columns.index(feature2)
            
            # Get feature values
            values1 = X_data[:, idx1]
            values2 = X_data[:, idx2]
            
            # Create interaction term
            interaction = values1 * values2
            
            # Calculate correlation
            correlation = np.corrcoef(values1, values2)[0, 1]
            
            # Calculate interaction strength
            interaction_strength = np.corrcoef(interaction, 
                                             self.model.predict(X_data))[0, 1]
            
            return {
                'feature1': feature1,
                'feature2': feature2,
                'correlation': float(correlation),
                'interaction_strength': float(interaction_strength),
                'interaction_values': interaction.tolist()
            }
            
        except Exception as e:
            return {"error": f"Error calculating interaction effects: {e}"}
    
    def generate_explanation_report(self, input_data: np.ndarray) -> Dict[str, Any]:
        """
        Generate a comprehensive explanation report
        
        Args:
            input_data: Single input sample
            
        Returns:
            Dictionary containing comprehensive explanation
        """
        try:
            # Get basic explanation
            explanation = self.explain_prediction(input_data)
            
            if "error" in explanation:
                return explanation
            
            # Get feature importance
            importance_data = self.get_feature_importance_plot()
            
            # Get waterfall data
            waterfall_data = self.get_waterfall_plot_data(input_data)
            
            # Generate insights
            insights = self._generate_insights(explanation, importance_data)
            
            return {
                'explanation': explanation,
                'feature_importance': importance_data,
                'waterfall': waterfall_data,
                'insights': insights,
                'timestamp': pd.Timestamp.now().isoformat()
            }
            
        except Exception as e:
            return {"error": f"Error generating explanation report: {e}"}
    
    def _generate_insights(self, explanation: Dict, importance_data: Dict) -> List[str]:
        """Generate human-readable insights from the explanation"""
        insights = []
        
        try:
            # Get top contributing features
            top_features = explanation.get('top_features', [])
            
            if top_features:
                # Feature contribution insights
                for i, feature in enumerate(top_features[:3]):
                    contribution = feature['contribution']
                    if abs(contribution) > 0.1:
                        direction = "increases" if contribution > 0 else "decreases"
                        insights.append(
                            f"{feature['feature']} {direction} the predicted yield by {abs(contribution):.2f} tons/ha"
                        )
                
                # Overall prediction insight
                prediction = explanation.get('prediction', 0)
                base_value = explanation.get('base_value', 0)
                
                if prediction > base_value:
                    insights.append(f"The predicted yield ({prediction:.2f} tons/ha) is above the average ({base_value:.2f} tons/ha)")
                else:
                    insights.append(f"The predicted yield ({prediction:.2f} tons/ha) is below the average ({base_value:.2f} tons/ha)")
            
            # Feature importance insights
            if 'feature_importance' in importance_data:
                top_important = importance_data['feature_importance'][:3]
                insights.append(f"The most important factors are: {', '.join([f['feature'] for f in top_important])}")
            
        except Exception as e:
            insights.append(f"Error generating insights: {e}")
        
        return insights

# Example usage
if __name__ == "__main__":
    # This would be used with a trained model
    print("ModelExplainer class ready for use with trained models")
