"""
Knowledge Graph and Rule-based System for Agricultural Recommendations
"""

import json
from typing import Dict, List, Any, Tuple
from dataclasses import dataclass

@dataclass
class Crop:
    name: str
    optimal_ph_min: float
    optimal_ph_max: float
    optimal_rainfall_min: float
    optimal_rainfall_max: float
    water_requirement: float
    fertilizer_requirement: str  # low, moderate, high
    season: str
    growth_period_days: int

@dataclass
class Soil:
    type: str
    water_holding_capacity: float
    drainage: str  # poor, moderate, good
    ph_range: Tuple[float, float]
    organic_matter_optimal: float

@dataclass
class Fertilizer:
    name: str
    npk_ratio: str
    sustainability_rating: str  # high, medium, low
    cost_per_kg: float
    environmental_impact: float  # 0-1 scale

class AgriculturalKnowledgeGraph:
    def __init__(self):
        """Initialize the agricultural knowledge graph"""
        self.crops = self._initialize_crops()
        self.soils = self._initialize_soils()
        self.fertilizers = self._initialize_fertilizers()
        self.compatibility_matrix = self._build_compatibility_matrix()
        self.rotation_rules = self._build_rotation_rules()
        self.sustainability_rules = self._build_sustainability_rules()
    
    def _initialize_crops(self) -> Dict[str, Crop]:
        """Initialize crop database"""
        return {
            'wheat': Crop('wheat', 6.0, 7.5, 500, 800, 400, 'moderate', 'rabi', 120),
            'rice': Crop('rice', 6.5, 7.5, 700, 1200, 800, 'high', 'kharif', 150),
            'maize': Crop('maize', 6.0, 7.0, 400, 800, 500, 'high', 'kharif', 100),
            'sugarcane': Crop('sugarcane', 6.5, 7.5, 1000, 2000, 1200, 'high', 'annual', 365),
            'cotton': Crop('cotton', 6.0, 8.0, 300, 600, 450, 'moderate', 'kharif', 180),
            'soybean': Crop('soybean', 6.0, 7.0, 300, 700, 400, 'moderate', 'kharif', 90),
            'potato': Crop('potato', 4.5, 6.0, 400, 600, 350, 'moderate', 'rabi', 90),
            'tomato': Crop('tomato', 6.0, 7.0, 300, 500, 300, 'moderate', 'kharif', 75),
            'onion': Crop('onion', 6.0, 7.0, 300, 500, 250, 'low', 'rabi', 120),
            'chili': Crop('chili', 6.0, 7.0, 400, 600, 350, 'moderate', 'kharif', 120)
        }
    
    def _initialize_soils(self) -> Dict[str, Soil]:
        """Initialize soil database"""
        return {
            'loamy': Soil('loamy', 0.8, 'good', (6.0, 7.5), 3.0),
            'clay': Soil('clay', 0.9, 'poor', (6.5, 7.5), 4.0),
            'sandy': Soil('sandy', 0.4, 'good', (6.0, 7.0), 2.0),
            'silty': Soil('silty', 0.7, 'moderate', (6.0, 7.5), 2.5),
            'peaty': Soil('peaty', 0.95, 'poor', (5.5, 6.5), 6.0),
            'chalky': Soil('chalky', 0.6, 'good', (7.0, 8.5), 1.5)
        }
    
    def _initialize_fertilizers(self) -> Dict[str, Fertilizer]:
        """Initialize fertilizer database"""
        return {
            'urea': Fertilizer('urea', '46-0-0', 'low', 0.8, 0.8),
            'npk': Fertilizer('npk', '20-20-20', 'medium', 1.2, 0.7),
            'compost': Fertilizer('compost', '2-1-1', 'high', 0.3, 0.2),
            'organic': Fertilizer('organic', '3-2-2', 'high', 0.5, 0.3),
            'dap': Fertilizer('dap', '18-46-0', 'medium', 1.0, 0.6),
            'mop': Fertilizer('mop', '0-0-60', 'medium', 0.9, 0.5),
            'vermicompost': Fertilizer('vermicompost', '1-1-1', 'high', 0.4, 0.1),
            'biofertilizer': Fertilizer('biofertilizer', '0-0-0', 'high', 0.6, 0.1)
        }
    
    def _build_compatibility_matrix(self) -> Dict[str, Dict[str, float]]:
        """Build crop-soil compatibility matrix"""
        return {
            'wheat': {'loamy': 0.95, 'clay': 0.80, 'sandy': 0.70, 'silty': 0.90, 'peaty': 0.60, 'chalky': 0.75},
            'rice': {'loamy': 0.85, 'clay': 0.90, 'sandy': 0.60, 'silty': 0.80, 'peaty': 0.70, 'chalky': 0.50},
            'maize': {'loamy': 0.90, 'clay': 0.75, 'sandy': 0.85, 'silty': 0.85, 'peaty': 0.65, 'chalky': 0.80},
            'sugarcane': {'loamy': 0.90, 'clay': 0.95, 'sandy': 0.70, 'silty': 0.85, 'peaty': 0.80, 'chalky': 0.60},
            'cotton': {'loamy': 0.85, 'clay': 0.80, 'sandy': 0.80, 'silty': 0.80, 'peaty': 0.70, 'chalky': 0.75},
            'soybean': {'loamy': 0.90, 'clay': 0.85, 'sandy': 0.85, 'silty': 0.90, 'peaty': 0.75, 'chalky': 0.80}
        }
    
    def _build_rotation_rules(self) -> Dict[str, List[str]]:
        """Build crop rotation rules"""
        return {
            'wheat': ['soybean', 'chickpea', 'lentil', 'mustard', 'fallow'],
            'rice': ['wheat', 'chickpea', 'mustard', 'fallow', 'green_manure'],
            'maize': ['wheat', 'chickpea', 'soybean', 'sunflower', 'fallow'],
            'sugarcane': ['wheat', 'chickpea', 'mustard', 'fallow', 'green_manure'],
            'cotton': ['wheat', 'chickpea', 'soybean', 'sunflower', 'fallow'],
            'soybean': ['wheat', 'maize', 'cotton', 'sunflower', 'fallow']
        }
    
    def _build_sustainability_rules(self) -> Dict[str, List[str]]:
        """Build sustainability rules"""
        return {
            'water_conservation': [
                'Use drip irrigation for water efficiency',
                'Implement mulching to retain soil moisture',
                'Practice rainwater harvesting',
                'Use drought-resistant crop varieties',
                'Implement precision irrigation scheduling'
            ],
            'soil_health': [
                'Apply organic compost regularly',
                'Use cover crops to prevent erosion',
                'Practice crop rotation',
                'Minimize tillage operations',
                'Use green manure crops'
            ],
            'pest_management': [
                'Implement integrated pest management (IPM)',
                'Use biological pest control methods',
                'Practice crop rotation to break pest cycles',
                'Use resistant crop varieties',
                'Maintain field sanitation'
            ],
            'nutrient_management': [
                'Conduct regular soil testing',
                'Use organic fertilizers',
                'Practice precision nutrient application',
                'Implement nutrient cycling',
                'Use biofertilizers'
            ],
            'biodiversity': [
                'Plant diverse crop varieties',
                'Maintain field borders with native plants',
                'Create wildlife corridors',
                'Use mixed cropping systems',
                'Preserve natural habitats'
            ]
        }
    
    def get_crop_recommendations(self, soil_type: str, ph_level: float, 
                               rainfall: float, season: str) -> List[Dict[str, Any]]:
        """Get crop recommendations based on soil and climate conditions"""
        recommendations = []
        
        for crop_name, crop in self.crops.items():
            if crop.season != season and season != 'any':
                continue
            
            # Check pH compatibility
            ph_suitable = crop.optimal_ph_min <= ph_level <= crop.optimal_ph_max
            
            # Check rainfall compatibility
            rainfall_suitable = crop.optimal_rainfall_min <= rainfall <= crop.optimal_rainfall_max
            
            # Get soil compatibility
            soil_compatibility = self.compatibility_matrix.get(crop_name, {}).get(soil_type, 0.5)
            
            # Calculate overall suitability score
            suitability_score = 0
            if ph_suitable:
                suitability_score += 0.3
            if rainfall_suitable:
                suitability_score += 0.3
            suitability_score += soil_compatibility * 0.4
            
            if suitability_score > 0.6:  # Only recommend if suitable
                recommendations.append({
                    'crop': crop_name,
                    'suitability_score': suitability_score,
                    'ph_suitable': ph_suitable,
                    'rainfall_suitable': rainfall_suitable,
                    'soil_compatibility': soil_compatibility,
                    'water_requirement': crop.water_requirement,
                    'fertilizer_requirement': crop.fertilizer_requirement,
                    'growth_period': crop.growth_period_days
                })
        
        # Sort by suitability score
        recommendations.sort(key=lambda x: x['suitability_score'], reverse=True)
        return recommendations
    
    def get_soil_management_recommendations(self, soil_type: str, ph_level: float, 
                                          organic_matter: float) -> List[str]:
        """Get soil management recommendations"""
        recommendations = []
        soil = self.soils.get(soil_type)
        
        if not soil:
            return ["Unknown soil type - conduct soil analysis"]
        
        # pH management
        if ph_level < soil.ph_range[0]:
            recommendations.append(f"Apply lime to increase pH from {ph_level} to {soil.ph_range[0]}-{soil.ph_range[1]}")
        elif ph_level > soil.ph_range[1]:
            recommendations.append(f"Apply sulfur to decrease pH from {ph_level} to {soil.ph_range[0]}-{soil.ph_range[1]}")
        
        # Organic matter management
        if organic_matter < soil.organic_matter_optimal:
            recommendations.append(f"Increase organic matter from {organic_matter}% to {soil.organic_matter_optimal}% using compost")
        
        # Drainage management
        if soil.drainage == 'poor':
            recommendations.append("Improve drainage by adding sand or creating raised beds")
        elif soil.drainage == 'moderate':
            recommendations.append("Consider drainage improvements for better water management")
        
        # Water holding capacity
        if soil.water_holding_capacity < 0.6:
            recommendations.append("Improve water holding capacity by adding organic matter")
        
        return recommendations
    
    def get_fertilizer_recommendations(self, crop: str, soil_type: str, 
                                     current_fertilizer: str) -> List[Dict[str, Any]]:
        """Get fertilizer recommendations"""
        recommendations = []
        crop_obj = self.crops.get(crop)
        
        if not crop_obj:
            return [{"error": "Crop not found in database"}]
        
        # Get fertilizer requirements
        if crop_obj.fertilizer_requirement == 'high':
            recommended_fertilizers = ['npk', 'dap', 'organic']
        elif crop_obj.fertilizer_requirement == 'moderate':
            recommended_fertilizers = ['urea', 'npk', 'compost', 'organic']
        else:
            recommended_fertilizers = ['compost', 'organic', 'vermicompost']
        
        for fert_name in recommended_fertilizers:
            fert = self.fertilizers.get(fert_name)
            if fert:
                # Calculate sustainability score
                sustainability_score = 0
                if fert.sustainability_rating == 'high':
                    sustainability_score = 0.9
                elif fert.sustainability_rating == 'medium':
                    sustainability_score = 0.6
                else:
                    sustainability_score = 0.3
                
                # Adjust for environmental impact
                sustainability_score -= fert.environmental_impact * 0.3
                sustainability_score = max(0, sustainability_score)
                
                recommendations.append({
                    'fertilizer': fert_name,
                    'npk_ratio': fert.npk_ratio,
                    'sustainability_score': sustainability_score,
                    'cost_per_kg': fert.cost_per_kg,
                    'environmental_impact': fert.environmental_impact,
                    'recommended_rate': self._get_fertilizer_rate(crop, fert_name, soil_type)
                })
        
        # Sort by sustainability score
        recommendations.sort(key=lambda x: x['sustainability_score'], reverse=True)
        return recommendations
    
    def _get_fertilizer_rate(self, crop: str, fertilizer: str, soil_type: str) -> str:
        """Get recommended fertilizer application rate"""
        rates = {
            'urea': {'wheat': '150-200 kg/ha', 'rice': '200-250 kg/ha', 'maize': '200-250 kg/ha'},
            'npk': {'wheat': '100-150 kg/ha', 'rice': '150-200 kg/ha', 'maize': '150-200 kg/ha'},
            'compost': {'wheat': '5-10 tons/ha', 'rice': '8-12 tons/ha', 'maize': '6-10 tons/ha'},
            'organic': {'wheat': '3-5 tons/ha', 'rice': '5-8 tons/ha', 'maize': '4-6 tons/ha'}
        }
        
        return rates.get(fertilizer, {}).get(crop, 'As per soil test recommendations')
    
    def get_crop_rotation_recommendations(self, current_crop: str, 
                                        soil_type: str) -> List[str]:
        """Get crop rotation recommendations"""
        rotation_crops = self.rotation_rules.get(current_crop, [])
        
        if not rotation_crops:
            return ["No specific rotation recommendations available"]
        
        recommendations = []
        for crop in rotation_crops:
            if crop in self.crops:
                crop_obj = self.crops[crop]
                soil_compatibility = self.compatibility_matrix.get(crop, {}).get(soil_type, 0.5)
                
                if soil_compatibility > 0.7:
                    recommendations.append(f"{crop.title()} - High compatibility with {soil_type} soil")
                elif soil_compatibility > 0.5:
                    recommendations.append(f"{crop.title()} - Moderate compatibility with {soil_type} soil")
        
        return recommendations
    
    def get_sustainability_practices(self, category: str = None) -> Dict[str, List[str]]:
        """Get sustainability practices by category"""
        if category:
            return {category: self.sustainability_rules.get(category, [])}
        return self.sustainability_rules
    
    def analyze_farming_system(self, crop: str, soil_type: str, 
                             fertilizer: str, ph_level: float, 
                             organic_matter: float, rainfall: float) -> Dict[str, Any]:
        """Comprehensive analysis of farming system"""
        
        analysis = {
            'crop_analysis': {},
            'soil_analysis': {},
            'fertilizer_analysis': {},
            'sustainability_score': 0,
            'recommendations': []
        }
        
        # Crop analysis
        crop_obj = self.crops.get(crop)
        if crop_obj:
            analysis['crop_analysis'] = {
                'optimal_ph_range': (crop_obj.optimal_ph_min, crop_obj.optimal_ph_max),
                'ph_suitable': crop_obj.optimal_ph_min <= ph_level <= crop_obj.optimal_ph_max,
                'optimal_rainfall_range': (crop_obj.optimal_rainfall_min, crop_obj.optimal_rainfall_max),
                'rainfall_suitable': crop_obj.optimal_rainfall_min <= rainfall <= crop_obj.optimal_rainfall_max,
                'water_requirement': crop_obj.water_requirement,
                'fertilizer_requirement': crop_obj.fertilizer_requirement
            }
        
        # Soil analysis
        soil_obj = self.soils.get(soil_type)
        if soil_obj:
            analysis['soil_analysis'] = {
                'optimal_ph_range': soil_obj.ph_range,
                'ph_suitable': soil_obj.ph_range[0] <= ph_level <= soil_obj.ph_range[1],
                'organic_matter_optimal': soil_obj.organic_matter_optimal,
                'organic_matter_suitable': organic_matter >= soil_obj.organic_matter_optimal * 0.8,
                'water_holding_capacity': soil_obj.water_holding_capacity,
                'drainage': soil_obj.drainage
            }
        
        # Fertilizer analysis
        fert_obj = self.fertilizers.get(fertilizer)
        if fert_obj:
            analysis['fertilizer_analysis'] = {
                'sustainability_rating': fert_obj.sustainability_rating,
                'environmental_impact': fert_obj.environmental_impact,
                'cost_per_kg': fert_obj.cost_per_kg,
                'npk_ratio': fert_obj.npk_ratio
            }
        
        # Calculate sustainability score
        sustainability_factors = []
        
        # pH suitability
        if analysis['crop_analysis'].get('ph_suitable', False):
            sustainability_factors.append(0.2)
        
        # Rainfall suitability
        if analysis['crop_analysis'].get('rainfall_suitable', False):
            sustainability_factors.append(0.2)
        
        # Organic matter
        if analysis['soil_analysis'].get('organic_matter_suitable', False):
            sustainability_factors.append(0.2)
        
        # Fertilizer sustainability
        if fert_obj and fert_obj.sustainability_rating == 'high':
            sustainability_factors.append(0.2)
        elif fert_obj and fert_obj.sustainability_rating == 'medium':
            sustainability_factors.append(0.1)
        
        # Environmental impact
        if fert_obj:
            sustainability_factors.append(0.2 * (1 - fert_obj.environmental_impact))
        
        analysis['sustainability_score'] = sum(sustainability_factors)
        
        # Generate recommendations
        recommendations = []
        
        if not analysis['crop_analysis'].get('ph_suitable', True):
            recommendations.append("Adjust soil pH to optimal range for the crop")
        
        if not analysis['crop_analysis'].get('rainfall_suitable', True):
            recommendations.append("Consider irrigation or drainage improvements")
        
        if not analysis['soil_analysis'].get('organic_matter_suitable', True):
            recommendations.append("Increase soil organic matter content")
        
        if fert_obj and fert_obj.sustainability_rating == 'low':
            recommendations.append("Consider switching to more sustainable fertilizers")
        
        analysis['recommendations'] = recommendations
        
        return analysis

# Example usage
if __name__ == "__main__":
    kg = AgriculturalKnowledgeGraph()
    
    # Get crop recommendations
    crop_recs = kg.get_crop_recommendations('loamy', 6.5, 600, 'rabi')
    print("Crop Recommendations:")
    for rec in crop_recs[:3]:
        print(f"- {rec['crop']}: {rec['suitability_score']:.2f}")
    
    # Get fertilizer recommendations
    fert_recs = kg.get_fertilizer_recommendations('wheat', 'loamy', 'urea')
    print("\nFertilizer Recommendations:")
    for rec in fert_recs[:3]:
        print(f"- {rec['fertilizer']}: {rec['sustainability_score']:.2f}")
    
    # Analyze farming system
    analysis = kg.analyze_farming_system('wheat', 'loamy', 'urea', 6.5, 2.1, 600)
    print(f"\nSustainability Score: {analysis['sustainability_score']:.2f}")
    print("Recommendations:", analysis['recommendations'])
