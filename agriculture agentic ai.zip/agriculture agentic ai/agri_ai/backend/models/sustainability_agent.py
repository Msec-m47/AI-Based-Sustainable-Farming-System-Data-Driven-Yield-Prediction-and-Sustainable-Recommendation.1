"""
Sustainability Agent using LLM for generating eco-friendly recommendations
"""

import openai
import os
from typing import Dict, List, Any
import json

class SustainabilityAgent:
    def __init__(self, api_key: str = None):
        """
        Initialize the sustainability agent
        
        Args:
            api_key: OpenAI API key. If None, will try to get from environment
        """
        self.api_key = api_key or os.getenv('OPENAI_API_KEY')
        if self.api_key:
            openai.api_key = self.api_key
        else:
            print("Warning: OpenAI API key not found. Using fallback recommendations.")
    
    def generate_sustainability_recommendations(self, 
                                              crop: str,
                                              soil_type: str,
                                              rainfall: float,
                                              fertilizer_type: str,
                                              ph_level: float,
                                              organic_matter: float,
                                              previous_crop: str = None,
                                              season: str = None) -> Dict[str, Any]:
        """
        Generate sustainability recommendations based on input parameters
        
        Returns:
            Dictionary containing various sustainability recommendations
        """
        if self.api_key:
            return self._generate_llm_recommendations(
                crop, soil_type, rainfall, fertilizer_type, 
                ph_level, organic_matter, previous_crop, season
            )
        else:
            return self._generate_fallback_recommendations(
                crop, soil_type, rainfall, fertilizer_type, 
                ph_level, organic_matter, previous_crop, season
            )
    
    def _generate_llm_recommendations(self, 
                                    crop: str,
                                    soil_type: str,
                                    rainfall: float,
                                    fertilizer_type: str,
                                    ph_level: float,
                                    organic_matter: float,
                                    previous_crop: str = None,
                                    season: str = None) -> Dict[str, Any]:
        """Generate recommendations using OpenAI GPT"""
        
        prompt = f"""
        As an agricultural sustainability expert, provide eco-friendly recommendations for the following farming scenario:

        Crop: {crop}
        Soil Type: {soil_type}
        Rainfall: {rainfall}mm
        Fertilizer Type: {fertilizer_type}
        Soil pH: {ph_level}
        Organic Matter: {organic_matter}%
        Previous Crop: {previous_crop or 'Not specified'}
        Season: {season or 'Not specified'}

        Please provide recommendations in the following categories:
        1. Soil Health Improvement
        2. Water Conservation
        3. Fertilizer Optimization
        4. Crop Rotation Strategy
        5. Organic Practices
        6. Environmental Impact Reduction

        Format your response as a JSON object with the following structure:
        {{
            "soil_health": {{
                "recommendations": ["recommendation1", "recommendation2"],
                "priority": "high/medium/low",
                "implementation": "easy/medium/hard"
            }},
            "water_conservation": {{
                "recommendations": ["recommendation1", "recommendation2"],
                "priority": "high/medium/low",
                "implementation": "easy/medium/hard"
            }},
            "fertilizer_optimization": {{
                "recommendations": ["recommendation1", "recommendation2"],
                "priority": "high/medium/low",
                "implementation": "easy/medium/hard"
            }},
            "crop_rotation": {{
                "recommendations": ["recommendation1", "recommendation2"],
                "priority": "high/medium/low",
                "implementation": "easy/medium/hard"
            }},
            "organic_practices": {{
                "recommendations": ["recommendation1", "recommendation2"],
                "priority": "high/medium/low",
                "implementation": "easy/medium/hard"
            }},
            "environmental_impact": {{
                "recommendations": ["recommendation1", "recommendation2"],
                "priority": "high/medium/low",
                "implementation": "easy/medium/hard"
            }},
            "overall_sustainability_score": 0.85,
            "key_benefits": ["benefit1", "benefit2", "benefit3"]
        }}

        Focus on practical, implementable solutions that balance yield optimization with environmental sustainability.
        """
        
        try:
            response = openai.ChatCompletion.create(
                model="gpt-3.5-turbo",
                messages=[
                    {"role": "system", "content": "You are an expert agricultural sustainability consultant with deep knowledge of eco-friendly farming practices."},
                    {"role": "user", "content": prompt}
                ],
                max_tokens=1500,
                temperature=0.7
            )
            
            content = response.choices[0].message.content
            # Try to extract JSON from the response
            try:
                # Find JSON in the response
                start_idx = content.find('{')
                end_idx = content.rfind('}') + 1
                json_str = content[start_idx:end_idx]
                return json.loads(json_str)
            except:
                # If JSON parsing fails, return structured fallback
                return self._parse_text_response(content)
                
        except Exception as e:
            print(f"Error calling OpenAI API: {e}")
            return self._generate_fallback_recommendations(
                crop, soil_type, rainfall, fertilizer_type, 
                ph_level, organic_matter, previous_crop, season
            )
    
    def _parse_text_response(self, text: str) -> Dict[str, Any]:
        """Parse text response into structured format"""
        return {
            "soil_health": {
                "recommendations": ["Apply organic compost to improve soil structure", "Use cover crops to prevent erosion"],
                "priority": "high",
                "implementation": "medium"
            },
            "water_conservation": {
                "recommendations": ["Implement drip irrigation system", "Use mulching to retain soil moisture"],
                "priority": "high",
                "implementation": "medium"
            },
            "fertilizer_optimization": {
                "recommendations": ["Switch to organic fertilizers", "Use precision application methods"],
                "priority": "medium",
                "implementation": "easy"
            },
            "crop_rotation": {
                "recommendations": ["Rotate with nitrogen-fixing crops", "Implement 3-year rotation cycle"],
                "priority": "high",
                "implementation": "easy"
            },
            "organic_practices": {
                "recommendations": ["Reduce chemical inputs", "Use biological pest control"],
                "priority": "medium",
                "implementation": "medium"
            },
            "environmental_impact": {
                "recommendations": ["Minimize soil disturbance", "Plant windbreaks"],
                "priority": "medium",
                "implementation": "easy"
            },
            "overall_sustainability_score": 0.75,
            "key_benefits": ["Improved soil health", "Reduced environmental impact", "Long-term yield stability"],
            "raw_response": text
        }
    
    def _generate_fallback_recommendations(self, 
                                         crop: str,
                                         soil_type: str,
                                         rainfall: float,
                                         fertilizer_type: str,
                                         ph_level: float,
                                         organic_matter: float,
                                         previous_crop: str = None,
                                         season: str = None) -> Dict[str, Any]:
        """Generate fallback recommendations using rule-based system"""
        
        recommendations = {
            "soil_health": {
                "recommendations": [],
                "priority": "medium",
                "implementation": "medium"
            },
            "water_conservation": {
                "recommendations": [],
                "priority": "medium",
                "implementation": "medium"
            },
            "fertilizer_optimization": {
                "recommendations": [],
                "priority": "medium",
                "implementation": "easy"
            },
            "crop_rotation": {
                "recommendations": [],
                "priority": "high",
                "implementation": "easy"
            },
            "organic_practices": {
                "recommendations": [],
                "priority": "medium",
                "implementation": "medium"
            },
            "environmental_impact": {
                "recommendations": [],
                "priority": "medium",
                "implementation": "easy"
            },
            "overall_sustainability_score": 0.7,
            "key_benefits": []
        }
        
        # Soil health recommendations
        if ph_level < 6.0:
            recommendations["soil_health"]["recommendations"].append("Apply lime to increase soil pH")
            recommendations["soil_health"]["priority"] = "high"
        elif ph_level > 7.5:
            recommendations["soil_health"]["recommendations"].append("Apply sulfur to decrease soil pH")
            recommendations["soil_health"]["priority"] = "high"
        
        if organic_matter < 2.0:
            recommendations["soil_health"]["recommendations"].append("Add organic compost to improve soil organic matter")
            recommendations["soil_health"]["priority"] = "high"
        
        # Water conservation recommendations
        if rainfall < 500:
            recommendations["water_conservation"]["recommendations"].extend([
                "Implement drip irrigation for water efficiency",
                "Use mulching to retain soil moisture",
                "Consider drought-resistant crop varieties"
            ])
            recommendations["water_conservation"]["priority"] = "high"
        elif rainfall > 1000:
            recommendations["water_conservation"]["recommendations"].extend([
                "Implement proper drainage systems",
                "Use raised beds to prevent waterlogging"
            ])
        
        # Fertilizer optimization
        if fertilizer_type.lower() in ['urea', 'npk']:
            recommendations["fertilizer_optimization"]["recommendations"].extend([
                "Consider switching to organic fertilizers",
                "Use split application to reduce nutrient loss",
                "Implement soil testing for precise nutrient management"
            ])
            recommendations["fertilizer_optimization"]["priority"] = "medium"
        
        # Crop rotation recommendations
        if previous_crop and previous_crop.lower() == crop.lower():
            recommendations["crop_rotation"]["recommendations"].extend([
                "Implement crop rotation to break pest cycles",
                "Consider planting nitrogen-fixing crops like legumes"
            ])
            recommendations["crop_rotation"]["priority"] = "high"
        
        # Organic practices
        if soil_type.lower() == 'clay':
            recommendations["organic_practices"]["recommendations"].extend([
                "Use green manure crops to improve soil structure",
                "Apply compost to enhance soil aeration"
            ])
        
        # Environmental impact
        recommendations["environmental_impact"]["recommendations"].extend([
            "Plant windbreaks to reduce soil erosion",
            "Use integrated pest management (IPM)",
            "Implement conservation tillage practices"
        ])
        
        # Calculate sustainability score
        score = 0.7
        if organic_matter > 3.0:
            score += 0.1
        if fertilizer_type.lower() in ['compost', 'organic']:
            score += 0.1
        if ph_level >= 6.0 and ph_level <= 7.5:
            score += 0.05
        if rainfall >= 500 and rainfall <= 1000:
            score += 0.05
        
        recommendations["overall_sustainability_score"] = min(1.0, score)
        
        # Key benefits
        recommendations["key_benefits"] = [
            "Improved soil health and fertility",
            "Reduced environmental impact",
            "Enhanced long-term yield stability",
            "Better water use efficiency"
        ]
        
        return recommendations
    
    def get_sustainability_score(self, recommendations: Dict[str, Any]) -> float:
        """Calculate overall sustainability score"""
        return recommendations.get("overall_sustainability_score", 0.7)
    
    def get_priority_recommendations(self, recommendations: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Get high-priority recommendations"""
        priority_recs = []
        for category, data in recommendations.items():
            if isinstance(data, dict) and data.get("priority") == "high":
                priority_recs.append({
                    "category": category,
                    "recommendations": data["recommendations"],
                    "implementation": data["implementation"]
                })
        return priority_recs

# Example usage
if __name__ == "__main__":
    agent = SustainabilityAgent()
    
    recommendations = agent.generate_sustainability_recommendations(
        crop="wheat",
        soil_type="loamy",
        rainfall=600,
        fertilizer_type="urea",
        ph_level=6.5,
        organic_matter=2.1,
        previous_crop="soybean",
        season="rabi"
    )
    
    print("Sustainability Recommendations:")
    print(json.dumps(recommendations, indent=2))
