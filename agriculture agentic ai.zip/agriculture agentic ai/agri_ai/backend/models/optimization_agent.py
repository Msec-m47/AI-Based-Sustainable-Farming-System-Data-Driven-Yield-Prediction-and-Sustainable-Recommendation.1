"""
Multi-objective Optimization Agent for balancing yield, environmental impact, and cost
"""

import numpy as np
import pandas as pd
from typing import Dict, List, Tuple, Any
from scipy.optimize import minimize
import json

class OptimizationAgent:
    def __init__(self):
        """Initialize the optimization agent"""
        self.objective_weights = {
            'yield': 0.4,      # 40% weight on yield maximization
            'environment': 0.3, # 30% weight on environmental impact minimization
            'cost': 0.3        # 30% weight on cost minimization
        }
        
        # Cost factors (per unit)
        self.cost_factors = {
            'fertilizer': {
                'urea': 0.8,      # $ per kg
                'npk': 1.2,       # $ per kg
                'compost': 0.3,   # $ per kg
                'organic': 0.5    # $ per kg
            },
            'irrigation': {
                'drip': 0.1,      # $ per mm
                'sprinkler': 0.05, # $ per mm
                'flood': 0.02     # $ per mm
            },
            'pest_control': {
                'chemical': 0.5,  # $ per application
                'organic': 0.2,   # $ per application
                'biological': 0.3 # $ per application
            }
        }
        
        # Environmental impact factors
        self.environmental_factors = {
            'fertilizer': {
                'urea': 0.8,      # High environmental impact
                'npk': 0.7,       # Medium-high impact
                'compost': 0.2,   # Low impact
                'organic': 0.3    # Low impact
            },
            'irrigation': {
                'drip': 0.1,      # Low water usage
                'sprinkler': 0.3, # Medium water usage
                'flood': 0.8      # High water usage
            },
            'pest_control': {
                'chemical': 0.9,  # High environmental impact
                'organic': 0.2,   # Low impact
                'biological': 0.3 # Low impact
            }
        }
    
    def optimize_farming_practices(self, 
                                 crop: str,
                                 soil_type: str,
                                 rainfall: float,
                                 current_fertilizer: str,
                                 ph_level: float,
                                 organic_matter: float,
                                 budget_constraint: float = 1000.0) -> Dict[str, Any]:
        """
        Optimize farming practices for multiple objectives
        
        Args:
            crop: Type of crop
            soil_type: Type of soil
            rainfall: Annual rainfall in mm
            current_fertilizer: Current fertilizer type
            ph_level: Soil pH level
            organic_matter: Soil organic matter percentage
            budget_constraint: Maximum budget in dollars
            
        Returns:
            Dictionary containing optimized recommendations
        """
        
        # Get base recommendations
        base_recommendations = self._get_base_recommendations(
            crop, soil_type, rainfall, ph_level, organic_matter
        )
        
        # Optimize fertilizer application
        fertilizer_opt = self._optimize_fertilizer(
            crop, soil_type, ph_level, organic_matter, budget_constraint
        )
        
        # Optimize irrigation strategy
        irrigation_opt = self._optimize_irrigation(
            crop, soil_type, rainfall, budget_constraint
        )
        
        # Optimize pest control
        pest_control_opt = self._optimize_pest_control(
            crop, soil_type, budget_constraint
        )
        
        # Calculate overall optimization score
        optimization_score = self._calculate_optimization_score(
            fertilizer_opt, irrigation_opt, pest_control_opt
        )
        
        # Generate implementation plan
        implementation_plan = self._generate_implementation_plan(
            fertilizer_opt, irrigation_opt, pest_control_opt, budget_constraint
        )
        
        return {
            "optimization_score": optimization_score,
            "fertilizer_optimization": fertilizer_opt,
            "irrigation_optimization": irrigation_opt,
            "pest_control_optimization": pest_control_opt,
            "implementation_plan": implementation_plan,
            "expected_benefits": self._calculate_expected_benefits(
                fertilizer_opt, irrigation_opt, pest_control_opt
            ),
            "cost_breakdown": self._calculate_cost_breakdown(
                fertilizer_opt, irrigation_opt, pest_control_opt
            ),
            "environmental_impact": self._calculate_environmental_impact(
                fertilizer_opt, irrigation_opt, pest_control_opt
            )
        }
    
    def _get_base_recommendations(self, crop: str, soil_type: str, 
                                rainfall: float, ph_level: float, 
                                organic_matter: float) -> Dict[str, Any]:
        """Get base recommendations based on crop and soil characteristics"""
        
        recommendations = {
            "crop_specific": {},
            "soil_management": {},
            "water_management": {}
        }
        
        # Crop-specific recommendations
        if crop.lower() == 'wheat':
            recommendations["crop_specific"] = {
                "optimal_ph": (6.0, 7.5),
                "water_requirement": 400,
                "fertilizer_requirement": "moderate"
            }
        elif crop.lower() == 'rice':
            recommendations["crop_specific"] = {
                "optimal_ph": (6.5, 7.5),
                "water_requirement": 800,
                "fertilizer_requirement": "high"
            }
        elif crop.lower() == 'maize':
            recommendations["crop_specific"] = {
                "optimal_ph": (6.0, 7.0),
                "water_requirement": 500,
                "fertilizer_requirement": "high"
            }
        
        # Soil management recommendations
        if ph_level < 6.0:
            recommendations["soil_management"]["ph_adjustment"] = "Apply lime"
        elif ph_level > 7.5:
            recommendations["soil_management"]["ph_adjustment"] = "Apply sulfur"
        
        if organic_matter < 2.0:
            recommendations["soil_management"]["organic_matter"] = "Add compost"
        
        # Water management recommendations
        if rainfall < 500:
            recommendations["water_management"]["strategy"] = "drip"
        elif rainfall > 1000:
            recommendations["water_management"]["strategy"] = "drainage"
        else:
            recommendations["water_management"]["strategy"] = "sprinkler"
        
        return recommendations
    
    def _optimize_fertilizer(self, crop: str, soil_type: str, ph_level: float,
                           organic_matter: float, budget: float) -> Dict[str, Any]:
        """Optimize fertilizer type and application rate"""
        
        # Available fertilizer options
        fertilizers = ['urea', 'npk', 'compost', 'organic']
        
        best_option = None
        best_score = -1
        best_rate = 0
        
        for fert in fertilizers:
            # Calculate yield potential
            yield_potential = self._calculate_yield_potential(
                crop, soil_type, fert, ph_level, organic_matter
            )
            
            # Calculate environmental impact
            env_impact = self.environmental_factors['fertilizer'][fert]
            
            # Calculate cost
            cost_per_kg = self.cost_factors['fertilizer'][fert]
            
            # Optimize application rate (kg/ha)
            optimal_rate = self._find_optimal_fertilizer_rate(
                fert, crop, soil_type, budget, cost_per_kg
            )
            
            # Calculate total cost
            total_cost = optimal_rate * cost_per_kg
            
            # Calculate optimization score
            score = (
                self.objective_weights['yield'] * yield_potential -
                self.objective_weights['environment'] * env_impact -
                self.objective_weights['cost'] * (total_cost / budget)
            )
            
            if score > best_score:
                best_score = score
                best_option = fert
                best_rate = optimal_rate
        
        return {
            "recommended_fertilizer": best_option,
            "application_rate": best_rate,
            "cost_per_hectare": best_rate * self.cost_factors['fertilizer'][best_option],
            "environmental_impact": self.environmental_factors['fertilizer'][best_option],
            "expected_yield_improvement": self._calculate_yield_potential(
                crop, soil_type, best_option, ph_level, organic_matter
            )
        }
    
    def _optimize_irrigation(self, crop: str, soil_type: str, 
                           rainfall: float, budget: float) -> Dict[str, Any]:
        """Optimize irrigation strategy"""
        
        irrigation_methods = ['drip', 'sprinkler', 'flood']
        
        best_method = None
        best_score = -1
        
        for method in irrigation_methods:
            # Calculate water efficiency
            water_efficiency = self._calculate_water_efficiency(method, soil_type)
            
            # Calculate environmental impact
            env_impact = self.environmental_factors['irrigation'][method]
            
            # Calculate cost
            cost = self._calculate_irrigation_cost(method, rainfall, budget)
            
            # Calculate optimization score
            score = (
                self.objective_weights['yield'] * water_efficiency -
                self.objective_weights['environment'] * env_impact -
                self.objective_weights['cost'] * (cost / budget)
            )
            
            if score > best_score:
                best_score = score
                best_method = method
        
        return {
            "recommended_method": best_method,
            "water_efficiency": self._calculate_water_efficiency(best_method, soil_type),
            "environmental_impact": self.environmental_factors['irrigation'][best_method],
            "estimated_cost": self._calculate_irrigation_cost(best_method, rainfall, budget),
            "water_savings": self._calculate_water_savings(best_method, rainfall)
        }
    
    def _optimize_pest_control(self, crop: str, soil_type: str, 
                             budget: float) -> Dict[str, Any]:
        """Optimize pest control strategy"""
        
        pest_methods = ['chemical', 'organic', 'biological']
        
        best_method = None
        best_score = -1
        
        for method in pest_methods:
            # Calculate effectiveness
            effectiveness = self._calculate_pest_control_effectiveness(method, crop)
            
            # Calculate environmental impact
            env_impact = self.environmental_factors['pest_control'][method]
            
            # Calculate cost
            cost = self.cost_factors['pest_control'][method]
            
            # Calculate optimization score
            score = (
                self.objective_weights['yield'] * effectiveness -
                self.objective_weights['environment'] * env_impact -
                self.objective_weights['cost'] * (cost / budget)
            )
            
            if score > best_score:
                best_score = score
                best_method = method
        
        return {
            "recommended_method": best_method,
            "effectiveness": self._calculate_pest_control_effectiveness(best_method, crop),
            "environmental_impact": self.environmental_factors['pest_control'][best_method],
            "cost_per_application": self.cost_factors['pest_control'][best_method],
            "application_frequency": self._get_application_frequency(best_method, crop)
        }
    
    def _calculate_yield_potential(self, crop: str, soil_type: str, 
                                 fertilizer: str, ph_level: float, 
                                 organic_matter: float) -> float:
        """Calculate potential yield based on various factors"""
        
        base_yield = {
            'wheat': 3.0,
            'rice': 4.0,
            'maize': 2.5,
            'sugarcane': 60.0,
            'cotton': 1.5,
            'soybean': 1.2
        }.get(crop.lower(), 2.0)
        
        # Adjust for soil type
        soil_multiplier = {
            'loamy': 1.0,
            'clay': 0.9,
            'sandy': 0.8
        }.get(soil_type.lower(), 1.0)
        
        # Adjust for fertilizer
        fertilizer_multiplier = {
            'urea': 1.1,
            'npk': 1.2,
            'compost': 1.0,
            'organic': 0.95
        }.get(fertilizer.lower(), 1.0)
        
        # Adjust for pH
        if 6.0 <= ph_level <= 7.5:
            ph_multiplier = 1.0
        else:
            ph_multiplier = 0.8
        
        # Adjust for organic matter
        om_multiplier = min(1.2, 1.0 + (organic_matter - 2.0) * 0.1)
        
        return base_yield * soil_multiplier * fertilizer_multiplier * ph_multiplier * om_multiplier
    
    def _find_optimal_fertilizer_rate(self, fertilizer: str, crop: str, 
                                    soil_type: str, budget: float, 
                                    cost_per_kg: float) -> float:
        """Find optimal fertilizer application rate"""
        
        # Base rates (kg/ha)
        base_rates = {
            'urea': 200,
            'npk': 150,
            'compost': 5000,
            'organic': 3000
        }
        
        base_rate = base_rates.get(fertilizer, 200)
        max_affordable = budget / cost_per_kg
        
        return min(base_rate, max_affordable)
    
    def _calculate_water_efficiency(self, method: str, soil_type: str) -> float:
        """Calculate water efficiency for irrigation method"""
        
        efficiency = {
            'drip': 0.9,
            'sprinkler': 0.7,
            'flood': 0.5
        }.get(method, 0.7)
        
        # Adjust for soil type
        if soil_type.lower() == 'sandy':
            efficiency *= 0.9
        elif soil_type.lower() == 'clay':
            efficiency *= 1.1
        
        return min(1.0, efficiency)
    
    def _calculate_irrigation_cost(self, method: str, rainfall: float, budget: float) -> float:
        """Calculate irrigation cost"""
        
        base_cost = {
            'drip': 500,
            'sprinkler': 300,
            'flood': 100
        }.get(method, 300)
        
        # Adjust based on rainfall deficit
        if rainfall < 500:
            multiplier = 1.5
        elif rainfall < 800:
            multiplier = 1.2
        else:
            multiplier = 0.8
        
        return min(base_cost * multiplier, budget * 0.3)
    
    def _calculate_water_savings(self, method: str, rainfall: float) -> float:
        """Calculate water savings compared to flood irrigation"""
        
        if method == 'flood':
            return 0.0
        
        flood_usage = 1000  # mm
        method_usage = {
            'drip': 400,
            'sprinkler': 600
        }.get(method, 600)
        
        return max(0, flood_usage - method_usage)
    
    def _calculate_pest_control_effectiveness(self, method: str, crop: str) -> float:
        """Calculate pest control effectiveness"""
        
        effectiveness = {
            'chemical': 0.9,
            'organic': 0.7,
            'biological': 0.8
        }.get(method, 0.7)
        
        # Adjust for crop susceptibility
        if crop.lower() in ['cotton', 'maize']:
            effectiveness *= 0.9  # More pest-prone crops
        
        return effectiveness
    
    def _get_application_frequency(self, method: str, crop: str) -> int:
        """Get recommended application frequency per season"""
        
        frequency = {
            'chemical': 3,
            'organic': 5,
            'biological': 4
        }.get(method, 3)
        
        return frequency
    
    def _calculate_optimization_score(self, fertilizer_opt: Dict, 
                                    irrigation_opt: Dict, 
                                    pest_opt: Dict) -> float:
        """Calculate overall optimization score"""
        
        yield_score = (
            fertilizer_opt["expected_yield_improvement"] * 0.4 +
            irrigation_opt["water_efficiency"] * 0.3 +
            pest_opt["effectiveness"] * 0.3
        )
        
        env_score = 1 - (
            fertilizer_opt["environmental_impact"] * 0.4 +
            irrigation_opt["environmental_impact"] * 0.3 +
            pest_opt["environmental_impact"] * 0.3
        )
        
        cost_score = 1 - (
            (fertilizer_opt["cost_per_hectare"] + 
             irrigation_opt["estimated_cost"] + 
             pest_opt["cost_per_application"] * pest_opt["application_frequency"]) / 1000
        )
        
        return (yield_score * self.objective_weights['yield'] +
                env_score * self.objective_weights['environment'] +
                cost_score * self.objective_weights['cost'])
    
    def _generate_implementation_plan(self, fertilizer_opt: Dict, 
                                    irrigation_opt: Dict, 
                                    pest_opt: Dict, 
                                    budget: float) -> List[Dict[str, Any]]:
        """Generate step-by-step implementation plan"""
        
        plan = []
        
        # Phase 1: Soil preparation
        plan.append({
            "phase": 1,
            "title": "Soil Preparation",
            "duration": "2-4 weeks",
            "cost": fertilizer_opt["cost_per_hectare"] * 0.3,
            "actions": [
                f"Test soil pH and adjust if needed",
                f"Apply {fertilizer_opt['recommended_fertilizer']} at {fertilizer_opt['application_rate']} kg/ha",
                "Prepare irrigation system"
            ]
        })
        
        # Phase 2: Planting and irrigation setup
        plan.append({
            "phase": 2,
            "title": "Planting and Irrigation",
            "duration": "1-2 weeks",
            "cost": irrigation_opt["estimated_cost"] * 0.5,
            "actions": [
                f"Install {irrigation_opt['recommended_method']} irrigation system",
                "Plant crops according to recommended spacing",
                "Set up monitoring systems"
            ]
        })
        
        # Phase 3: Maintenance
        plan.append({
            "phase": 3,
            "title": "Crop Maintenance",
            "duration": "Growing season",
            "cost": pest_opt["cost_per_application"] * pest_opt["application_frequency"],
            "actions": [
                f"Apply {pest_opt['recommended_method']} pest control {pest_opt['application_frequency']} times",
                "Monitor soil moisture and adjust irrigation",
                "Regular crop health checks"
            ]
        })
        
        return plan
    
    def _calculate_expected_benefits(self, fertilizer_opt: Dict, 
                                   irrigation_opt: Dict, 
                                   pest_opt: Dict) -> Dict[str, Any]:
        """Calculate expected benefits of optimization"""
        
        yield_improvement = fertilizer_opt["expected_yield_improvement"]
        water_savings = irrigation_opt["water_savings"]
        
        return {
            "yield_increase_percent": (yield_improvement - 2.0) / 2.0 * 100,
            "water_savings_percent": water_savings / 1000 * 100,
            "environmental_impact_reduction": 1 - (
                fertilizer_opt["environmental_impact"] * 0.4 +
                irrigation_opt["environmental_impact"] * 0.3 +
                pest_opt["environmental_impact"] * 0.3
            ),
            "estimated_roi": self._calculate_roi(fertilizer_opt, irrigation_opt, pest_opt)
        }
    
    def _calculate_roi(self, fertilizer_opt: Dict, 
                      irrigation_opt: Dict, 
                      pest_opt: Dict) -> float:
        """Calculate return on investment"""
        
        total_cost = (
            fertilizer_opt["cost_per_hectare"] +
            irrigation_opt["estimated_cost"] +
            pest_opt["cost_per_application"] * pest_opt["application_frequency"]
        )
        
        # Assume crop price of $200 per ton
        crop_price = 200
        yield_value = fertilizer_opt["expected_yield_improvement"] * crop_price
        
        if total_cost > 0:
            return (yield_value - total_cost) / total_cost * 100
        return 0
    
    def _calculate_cost_breakdown(self, fertilizer_opt: Dict, 
                                irrigation_opt: Dict, 
                                pest_opt: Dict) -> Dict[str, float]:
        """Calculate detailed cost breakdown"""
        
        return {
            "fertilizer_cost": fertilizer_opt["cost_per_hectare"],
            "irrigation_cost": irrigation_opt["estimated_cost"],
            "pest_control_cost": pest_opt["cost_per_application"] * pest_opt["application_frequency"],
            "total_cost": (
                fertilizer_opt["cost_per_hectare"] +
                irrigation_opt["estimated_cost"] +
                pest_opt["cost_per_application"] * pest_opt["application_frequency"]
            )
        }
    
    def _calculate_environmental_impact(self, fertilizer_opt: Dict, 
                                     irrigation_opt: Dict, 
                                     pest_opt: Dict) -> Dict[str, float]:
        """Calculate environmental impact metrics"""
        
        return {
            "fertilizer_impact": fertilizer_opt["environmental_impact"],
            "irrigation_impact": irrigation_opt["environmental_impact"],
            "pest_control_impact": pest_opt["environmental_impact"],
            "overall_impact": (
                fertilizer_opt["environmental_impact"] * 0.4 +
                irrigation_opt["environmental_impact"] * 0.3 +
                pest_opt["environmental_impact"] * 0.3
            )
        }

# Example usage
if __name__ == "__main__":
    agent = OptimizationAgent()
    
    optimization_result = agent.optimize_farming_practices(
        crop="wheat",
        soil_type="loamy",
        rainfall=600,
        current_fertilizer="urea",
        ph_level=6.5,
        organic_matter=2.1,
        budget_constraint=1000.0
    )
    
    print("Optimization Results:")
    print(json.dumps(optimization_result, indent=2))
