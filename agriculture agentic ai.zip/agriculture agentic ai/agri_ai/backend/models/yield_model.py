"""
Yield Prediction Model using Random Forest Regressor
"""

import pandas as pd
import numpy as np
from sklearn.ensemble import RandomForestRegressor
from sklearn.preprocessing import LabelEncoder, StandardScaler
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error, r2_score
import joblib
import os

class YieldPredictionModel:
    def __init__(self):
        self.model = RandomForestRegressor(
            n_estimators=100,
            max_depth=10,
            random_state=42,
            n_jobs=-1
        )
        self.label_encoders = {}
        self.scaler = StandardScaler()
        self.is_trained = False
        self.feature_columns = []
        
    def prepare_data(self, df):
        """Prepare data for training/prediction"""
        # Create a copy to avoid modifying original data
        data = df.copy()
        
        # Encode categorical variables
        categorical_columns = ['crop', 'soil_type', 'fertilizer_type', 'previous_crop', 'season']
        
        for col in categorical_columns:
            if col in data.columns:
                if col not in self.label_encoders:
                    self.label_encoders[col] = LabelEncoder()
                    data[col] = self.label_encoders[col].fit_transform(data[col].astype(str))
                else:
                    # Handle unseen categories
                    data[col] = data[col].astype(str)
                    known_categories = self.label_encoders[col].classes_
                    data[col] = data[col].apply(lambda x: x if x in known_categories else 'unknown')
                    data[col] = self.label_encoders[col].transform(data[col])
        
        # Select feature columns (exclude target)
        feature_columns = [col for col in data.columns if col != 'yield_tons_per_ha']
        self.feature_columns = feature_columns
        
        return data[feature_columns], data['yield_tons_per_ha'] if 'yield_tons_per_ha' in data.columns else None
    
    def train(self, df):
        """Train the model"""
        print("Preparing data for training...")
        X, y = self.prepare_data(df)
        
        if y is None:
            raise ValueError("Target column 'yield_tons_per_ha' not found in data")
        
        # Split data
        X_train, X_test, y_train, y_test = train_test_split(
            X, y, test_size=0.2, random_state=42
        )
        
        # Scale features
        X_train_scaled = self.scaler.fit_transform(X_train)
        X_test_scaled = self.scaler.transform(X_test)
        
        print("Training Random Forest model...")
        self.model.fit(X_train_scaled, y_train)
        
        # Evaluate model
        y_pred = self.model.predict(X_test_scaled)
        mse = mean_squared_error(y_test, y_pred)
        r2 = r2_score(y_test, y_pred)
        
        print(f"Model trained successfully!")
        print(f"R² Score: {r2:.4f}")
        print(f"RMSE: {np.sqrt(mse):.4f}")
        
        self.is_trained = True
        return r2, np.sqrt(mse)
    
    def predict(self, input_data):
        """Make predictions on new data"""
        if not self.is_trained:
            raise ValueError("Model must be trained before making predictions")
        
        # Prepare input data
        X = self.prepare_data(input_data)[0]
        
        # Ensure all required columns are present
        missing_cols = set(self.feature_columns) - set(X.columns)
        if missing_cols:
            for col in missing_cols:
                X[col] = 0  # Default value for missing columns
        
        # Reorder columns to match training data
        X = X[self.feature_columns]
        
        # Scale features
        X_scaled = self.scaler.transform(X)
        
        # Make prediction
        prediction = self.model.predict(X_scaled)[0]
        
        # Calculate confidence based on prediction variance
        predictions = [tree.predict(X_scaled)[0] for tree in self.model.estimators_]
        confidence = 1 - (np.std(predictions) / (np.mean(predictions) + 1e-8))
        confidence = max(0, min(1, confidence))  # Clamp between 0 and 1
        
        return prediction, confidence
    
    def get_feature_importance(self):
        """Get feature importance scores"""
        if not self.is_trained:
            return {}
        
        importance = self.model.feature_importances_
        feature_names = self.feature_columns
        
        return dict(zip(feature_names, importance))
    
    def save_model(self, filepath):
        """Save the trained model and encoders"""
        model_data = {
            'model': self.model,
            'label_encoders': self.label_encoders,
            'scaler': self.scaler,
            'feature_columns': self.feature_columns,
            'is_trained': self.is_trained
        }
        joblib.dump(model_data, filepath)
        print(f"Model saved to {filepath}")
    
    def load_model(self, filepath):
        """Load a trained model"""
        if not os.path.exists(filepath):
            raise FileNotFoundError(f"Model file not found: {filepath}")
        
        model_data = joblib.load(filepath)
        self.model = model_data['model']
        self.label_encoders = model_data['label_encoders']
        self.scaler = model_data['scaler']
        self.feature_columns = model_data['feature_columns']
        self.is_trained = model_data['is_trained']
        
        print(f"Model loaded from {filepath}")

# Example usage and training
if __name__ == "__main__":
    # Load sample data
    df = pd.read_csv('../../datasets/sample_agri_data.csv')
    
    # Initialize and train model
    model = YieldPredictionModel()
    r2, rmse = model.train(df)
    
    # Save model
    model.save_model('yield_model.pkl')
    
    # Test prediction
    sample_input = pd.DataFrame({
        'crop': ['wheat'],
        'soil_type': ['loamy'],
        'rainfall_mm': [600],
        'fertilizer_type': ['urea'],
        'ph_level': [6.5],
        'organic_matter': [2.1],
        'previous_crop': ['soybean'],
        'season': ['rabi'],
        'temperature_avg': [22],
        'humidity_avg': [65]
    })
    
    prediction, confidence = model.predict(sample_input)
    print(f"Predicted yield: {prediction:.2f} tons/ha")
    print(f"Confidence: {confidence:.2f}")
